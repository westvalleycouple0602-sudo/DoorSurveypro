# new-customer - new-lead-welcome

**Subject:** Welcome to DoorSurvey Pro – Let’s Get Started

Hi {{FirstName}},  
Thank you for reaching out! We received your request and are excited to help you with your door, frame, and hardware needs.

Our team will review the details you submitted and follow up shortly with next steps. If this is urgent, feel free to call us directly at {{PhoneNumber}}.

Looking forward to working with you!  
— The DoorSurvey Pro Team
