// backend/src/openings/openingDtos.ts
import {
  Div28SurveyAnswers,
  Div28OpportunitySummary,
} from "../div28/div28Types";
import { GeneratedDiv28Task } from "../div28/div28PmTasks";

export type DoorFunction =
  | "SINGLE_SWING"
  | "PAIR_SWING"
  | "SLIDING"
  | "FOLDING"
  | "OTHER";

export type FireRating =
  | "NON_RATED"
  | "20_MIN"
  | "45_MIN"
  | "60_MIN"
  | "90_MIN"
  | "3_HOUR";

export type FrameMaterial = "HOLLOW_METAL" | "ALUMINUM" | "WOOD" | "FRP";

export interface OpeningDiv8Core {
  openingNumber: string;
  name?: string;
  locationDescription?: string;
  doorFunction: DoorFunction;
  fireRating: FireRating;
  frameMaterial: FrameMaterial;
  hand?: string;
  roughOpeningWidthMm?: number;
  roughOpeningHeightMm?: number;
  leafWidthMm?: number;
  leafHeightMm?: number;
  hardwareSetId?: string;
}

export interface OpeningDiv28Bundle {
  div28Survey: Div28SurveyAnswers;
  div28Opportunity: Div28OpportunitySummary | null;
}

export interface OpeningRecord extends OpeningDiv8Core, OpeningDiv28Bundle {
  id: string;
  projectId: string;
  createdAt: string;
  updatedAt: string;
}

export interface OpeningCreatePayload extends OpeningDiv8Core {
  projectId: string;
  div28Survey: Div28SurveyAnswers;
}

export interface OpeningUpdatePayload {
  id: string;
  projectId: string;
  div8?: Partial<OpeningDiv8Core>;
  div28Survey?: Div28SurveyAnswers;
}

export interface OpeningWithTasksAndProposalResponse {
  opening: OpeningRecord;
  div28Tasks: GeneratedDiv28Task[];
  proposal: {
    baseOptionText: string;
    upgradeBlocks: {
      id: string;
      title: string;
      body: string;
      appliesToFeatures: string[];
    }[];
    summary: string;
  };
}
