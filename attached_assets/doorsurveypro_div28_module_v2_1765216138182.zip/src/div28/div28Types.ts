// src/div28/div28Types.ts
export type RiskLevel = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

export type AreaType =
  | "PUBLIC"
  | "STAFF_ONLY"
  | "CRITICAL_CARE"
  | "PHARMACY"
  | "BEHAVIORAL_HEALTH"
  | "IT_DATA_CENTER"
  | "ADMIN"
  | "OTHER";

export type AccessControlMode =
  | "NONE"
  | "MECHANICAL_ONLY"
  | "BADGE_CARD"
  | "PIN_KEYPAD"
  | "BADGE_PLUS_PIN"
  | "MOBILE_CREDENTIAL";

export type LockdownCoverage =
  | "NONE"
  | "LOCAL_ONLY"
  | "ZONE_LOCKDOWN"
  | "BUILDING_LOCKDOWN";

export type EgressType =
  | "FREE_EGRESS"
  | "CONTROLLED_EGRESS"
  | "DELAYED_EGRESS"
  | "SPECIAL_LOCKING_ARRANGEMENT";

export type SurveillanceLevel =
  | "NONE"
  | "LOCAL_CAMERA"
  | "EXISTING_VIDEO_INTEGRATION"
  | "ANALYTICS_READY";

export type IntrusionLevel =
  | "NONE"
  | "DOOR_CONTACT_ONLY"
  | "DOOR_PLUS_MOTION"
  | "DOOR_PLUS_GLASSBREAK";

export type GunDetectionIntent = "NONE" | "INTERESTED" | "REQUIRED";

export type Div28Feature =
  | "ACCESS_CONTROL"
  | "DOOR_AUTOMATION"
  | "CONTROLLED_EGRESS"
  | "DELAYED_EGRESS"
  | "SURVEILLANCE"
  | "INTRUSION_DETECTION"
  | "GUN_DETECTION_READY"
  | "LOCKDOWN_CONTROL";

export interface Div28SurveyAnswers {
  openingId: string;
  areaType: AreaType;
  riskLevel: RiskLevel;
  accessControlMode: AccessControlMode;
  requiresAuditTrail: boolean;
  scheduledLockUnlock: boolean;
  egressType: EgressType;
  unsureAboutEgressCode: boolean;
  heavyOrHighTraffic: boolean;
  adaPriority: boolean;
  infectionControlPriority: boolean;
  surveillanceLevel: SurveillanceLevel;
  intrusionLevel: IntrusionLevel;
  lockdownCoverage: LockdownCoverage;
  gunDetectionIntent: GunDetectionIntent;
  notes?: string;
}

export interface Div28OpportunitySummary {
  openingId: string;
  score: number;
  tier: "NONE" | "LOW" | "MEDIUM" | "HIGH";
  recommendedFeatures: Div28Feature[];
  narrativeSummary: string;
  warnings: string[];
}
