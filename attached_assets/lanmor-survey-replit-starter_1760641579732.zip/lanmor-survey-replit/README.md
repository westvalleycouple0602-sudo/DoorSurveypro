# Lanmor Door Opening Survey — Replit Starter
Run on Replit:
1) Create a Python repl.
2) Upload this folder or ZIP.
3) It will install deps and start: /docs shows interactive API.

Endpoints:
- GET /schema
- GET /templates, GET /templates/{project|openings|hardware|electrification}
- POST /validate (send JSON payload to validate against schema)
