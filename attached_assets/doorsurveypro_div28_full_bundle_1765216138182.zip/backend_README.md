# Backend – Div 8 + Div 28 Openings, Tasks & Proposal Text

This backend provides:

- Drizzle/Postgres schema for openings (Div 8 + Div 28 metadata).
- Div 28 scoring, PM tasks, and proposal text generation.
- Express API that returns an opening **plus** Div 28 tasks and proposal text.

Key files:

- `src/db/schema.ts` / `src/db/client.ts`
- `src/div28/div28Types.ts`
- `src/div28/div28OpportunityScoring.ts`
- `src/div28/div28PmTasks.ts`
- `src/div28/div28ProposalSnippets.ts`
- `src/openings/openingDtos.ts`
- `src/openings/openingsRepository.ts`
- `src/openings/openingsRouter.ts`
- `src/server.ts`

Routes:

- `GET /api/openings/:id` → `OpeningRecord`
- `POST /api/openings` → `OpeningWithTasksAndProposalResponse`
- `PUT /api/openings/:id` → `OpeningWithTasksAndProposalResponse`

Set `DATABASE_URL` to your Postgres instance and start `server.ts`.
