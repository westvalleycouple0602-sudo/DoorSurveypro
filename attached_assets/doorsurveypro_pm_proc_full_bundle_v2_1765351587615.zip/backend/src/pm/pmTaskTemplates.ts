// backend/src/pm/pmTaskTemplates.ts
import type {
  PmPhase,
  PmTaskType,
  PmDiscipline,
  PmTask,
  PmFeatureTag,
} from "./pmTypes";
import { v4 as uuidv4 } from "uuid";

export interface PmTaskTemplate {
  id: string;
  phase: PmPhase;
  discipline: PmDiscipline;
  type: PmTaskType;
  title: string;
  description: string;
  defaultRedFlag: boolean;
  featureTags?: PmFeatureTag[];
}

export const pmTaskTemplates: PmTaskTemplate[] = [
  //
  // PRE-CONTRACT – DIV 8 & DIV 28
  //
  {
    id: "precon-001",
    phase: "PRE_CONTRACT",
    discipline: "DIV8",
    type: "CHECKLIST",
    title: "Verify door and hardware schedule alignment",
    description:
      "Ensure the opening schedule, hardware sets, and specifications are aligned before pricing.",
    defaultRedFlag: false,
    featureTags: ["GENERAL_SECURITY"],
  },
  {
    id: "precon-002",
    phase: "PRE_CONTRACT",
    discipline: "DIV28",
    type: "CHECKLIST",
    title: "Identify Div 28 scope tied to Div 8 openings",
    description:
      "List access control, automatic operators, controlled egress, delayed egress, and surveillance required at door openings.",
    defaultRedFlag: false,
    featureTags: [
      "ACCESS_CONTROL",
      "AUTOMATIC_OPERATORS",
      "CONTROLLED_EGRESS",
      "DELAYED_EGRESS",
      "CAMERA_SURVEILLANCE",
      "INTRUSION",
      "LOCKDOWN",
    ],
  },
  {
    id: "precon-003",
    phase: "PRE_CONTRACT",
    discipline: "DIV28",
    type: "MEETING_NOTE",
    title: "Review sequence-of-operations expectations",
    description:
      "Capture owner expectations for access control, lockdown behavior, door monitoring, and alarm responses.",
    defaultRedFlag: false,
    featureTags: ["ACCESS_CONTROL", "LOCKDOWN", "GENERAL_SECURITY"],
  },
  {
    id: "precon-004",
    phase: "PRE_CONTRACT",
    discipline: "DIV28",
    type: "CHECKLIST",
    title: "Confirm integration with existing security platforms",
    description:
      "Identify existing access control, video management, intrusion, and mass notification platforms to integrate with.",
    defaultRedFlag: false,
    featureTags: ["NETWORK_IT", "CAMERA_SURVEILLANCE", "INTRUSION"],
  },

  //
  // CONTRACT EXECUTED – DIV 28
  //
  {
    id: "contract-028-001",
    phase: "CONTRACT_EXECUTED",
    discipline: "DIV28",
    type: "CHECKLIST",
    title: "Build Div 28 device list by opening",
    description:
      "Generate a device list for each opening including readers, REX, DPS, operators, cameras, and sensors.",
    defaultRedFlag: false,
    featureTags: [
      "ACCESS_CONTROL",
      "AUTOMATIC_OPERATORS",
      "CAMERA_SURVEILLANCE",
      "INTRUSION",
    ],
  },
  {
    id: "contract-028-002",
    phase: "CONTRACT_EXECUTED",
    discipline: "DIV28",
    type: "CHECKLIST",
    title: "Define low-voltage scope responsibility matrix",
    description:
      "Clarify which party is responsible for cabling, terminations, programming, and testing for each Div 28 system.",
    defaultRedFlag: false,
    featureTags: ["NETWORK_IT", "FIRE_ALARM_INTEGRATION", "GENERAL_SECURITY"],
  },
  {
    id: "contract-028-003",
    phase: "CONTRACT_EXECUTED",
    discipline: "DIV28",
    type: "DOCUMENT",
    title: "Lockdown and threat-response matrix draft",
    description:
      "Create a draft matrix showing how each area and opening behaves during lockdown, shelter-in-place, and other emergency modes.",
    defaultRedFlag: false,
    featureTags: ["LOCKDOWN", "GENERAL_SECURITY"],
  },

  //
  // SUBMITTALS – DIV 8 & DIV 28
  //
  {
    id: "submittal-001",
    phase: "SUBMITTALS",
    discipline: "DIV8",
    type: "SUBMITTAL",
    title: "Prepare door and hardware submittal package",
    description:
      "Generate and submit door, frame, and hardware submittals including catalog cuts and schedule.",
    defaultRedFlag: false,
    featureTags: ["GENERAL_SECURITY"],
  },
  {
    id: "submittal-002",
    phase: "SUBMITTALS",
    discipline: "DIV28",
    type: "SUBMITTAL",
    title: "Prepare access control and security submittals",
    description:
      "Provide device layouts, riser diagrams, and sequence-of-operations for Div 28 systems tied to doors.",
    defaultRedFlag: false,
    featureTags: [
      "ACCESS_CONTROL",
      "AUTOMATIC_OPERATORS",
      "CAMERA_SURVEILLANCE",
      "INTRUSION",
      "LOCKDOWN",
    ],
  },
  {
    id: "submittal-028-003",
    phase: "SUBMITTALS",
    discipline: "DIV28",
    type: "SUBMITTAL",
    title: "Submit panel, power, and battery calculations",
    description:
      "Submit load calculations for access control panels, power supplies, and batteries including 4/24 hour standby requirements.",
    defaultRedFlag: false,
    featureTags: ["POWER_SUPPLIES", "ACCESS_CONTROL"],
  },
  {
    id: "submittal-028-004",
    phase: "SUBMITTALS",
    discipline: "DIV28",
    type: "SUBMITTAL",
    title: "Submit network and VLAN requirements",
    description:
      "Document IP addressing, VLAN, QoS, and bandwidth requirements for security devices (readers, controllers, cameras, servers).",
    defaultRedFlag: false,
    featureTags: ["NETWORK_IT", "CAMERA_SURVEILLANCE", "ACCESS_CONTROL"],
  },
  {
    id: "submittal-028-005",
    phase: "SUBMITTALS",
    discipline: "DIV28",
    type: "RFI",
    title: "Clarify conflicting security, egress, or fire-alarm notes",
    description:
      "Issue RFIs where Div 28 scope appears to conflict with life-safety, egress, or architectural details.",
    defaultRedFlag: true,
    featureTags: ["FIRE_ALARM_INTEGRATION", "CONTROLLED_EGRESS", "DELAYED_EGRESS"],
  },

  //
  // PROCUREMENT – DIV 8 & DIV 28
  //
  {
    id: "proc-001",
    phase: "PROCUREMENT",
    discipline: "DIV8",
    type: "PROCUREMENT",
    title: "Release door and hardware purchase orders",
    description:
      "Issue POs to door, frame, and hardware manufacturers based on approved submittals.",
    defaultRedFlag: false,
    featureTags: ["GENERAL_SECURITY"],
  },
  {
    id: "proc-002",
    phase: "PROCUREMENT",
    discipline: "DIV28",
    type: "PROCUREMENT",
    title: "Release access control and operator purchase orders",
    description:
      "Issue POs to access control, automatic operator, and security vendors for openings on the project.",
    defaultRedFlag: false,
    featureTags: ["ACCESS_CONTROL", "AUTOMATIC_OPERATORS"],
  },
  {
    id: "proc-028-003",
    phase: "PROCUREMENT",
    discipline: "DIV28",
    type: "PROCUREMENT",
    title: "Verify long-lead Div 28 devices and panels",
    description:
      "Flag long-lead controllers, power supplies, readers, cameras, and specialty devices and confirm lead times with vendors.",
    defaultRedFlag: true,
    featureTags: [
      "ACCESS_CONTROL",
      "CAMERA_SURVEILLANCE",
      "POWER_SUPPLIES",
      "GENERAL_SECURITY",
    ],
  },
  {
    id: "proc-028-004",
    phase: "PROCUREMENT",
    discipline: "DIV28",
    type: "CHECKLIST",
    title: "Confirm licenses and cloud service subscriptions",
    description:
      "Confirm required software licenses, server sizing, and cloud subscriptions for access control and video platforms.",
    defaultRedFlag: false,
    featureTags: ["CLOUD_LICENSES", "ACCESS_CONTROL", "CAMERA_SURVEILLANCE"],
  },
  {
    id: "proc-028-005",
    phase: "PROCUREMENT",
    discipline: "DIV28",
    type: "CHECKLIST",
    title: "Review coordination with fire alarm and BMS vendors",
    description:
      "Confirm who provides and wires relays, monitoring points, and override signals between Div 28, fire alarm, and building management systems.",
    defaultRedFlag: true,
    featureTags: ["FIRE_ALARM_INTEGRATION", "LOCKDOWN"],
  },

  //
  // INSTALLATION – DIV 8 & DIV 28
  //
  {
    id: "install-001",
    phase: "INSTALLATION",
    discipline: "DIV8",
    type: "FIELD_ISSUE",
    title: "Document field conditions impacting openings",
    description:
      "Capture site deviations (wall thickness, clearances, blocking) that affect door and frame installation.",
    defaultRedFlag: true,
    featureTags: ["GENERAL_SECURITY"],
  },
  {
    id: "install-002",
    phase: "INSTALLATION",
    discipline: "DIV28",
    type: "FIELD_ISSUE",
    title: "Coordinate Div 28 cabling and device mounting",
    description:
      "Confirm power, data, and device mounting for access control, operators, and cameras at each opening.",
    defaultRedFlag: true,
    featureTags: [
      "ACCESS_CONTROL",
      "AUTOMATIC_OPERATORS",
      "CAMERA_SURVEILLANCE",
      "NETWORK_IT",
    ],
  },
  {
    id: "install-028-003",
    phase: "INSTALLATION",
    discipline: "DIV28",
    type: "CHECKLIST",
    title: "Verify access control panel and power wiring",
    description:
      "Confirm field wiring is landed per approved riser, polarity is correct, and fusing/breakers match drawings.",
    defaultRedFlag: true,
    featureTags: ["ACCESS_CONTROL", "POWER_SUPPLIES"],
  },
  {
    id: "install-028-004",
    phase: "INSTALLATION",
    discipline: "DIV28",
    type: "CHECKLIST",
    title: "Label controllers, power supplies, and door circuits",
    description:
      "Label panels, power supplies, and individual circuits so doors can be quickly identified during commissioning and service.",
    defaultRedFlag: false,
    featureTags: ["ACCESS_CONTROL", "POWER_SUPPLIES", "COMMISSIONING"],
  },
  {
    id: "install-028-005",
    phase: "INSTALLATION",
    discipline: "DIV28",
    type: "FIELD_ISSUE",
    title: "Confirm device mounting heights and ADA reach ranges",
    description:
      "Verify that readers, keypads, REX, push-to-exit, and operator actuators comply with ADA and project standards.",
    defaultRedFlag: true,
    featureTags: ["ACCESS_CONTROL", "AUTOMATIC_OPERATORS"],
  },

  //
  // PUNCH – DIV 28 FUNCTIONAL TESTS
  //
  {
    id: "punch-028-001",
    phase: "PUNCH",
    discipline: "DIV28",
    type: "CHECKLIST",
    title: "Access control functional test by opening",
    description:
      "Test credential presentation, schedules, door monitoring, and forced/held conditions for each electrified opening.",
    defaultRedFlag: true,
    featureTags: ["ACCESS_CONTROL", "COMMISSIONING"],
  },
  {
    id: "punch-028-002",
    phase: "PUNCH",
    discipline: "DIV28",
    type: "CHECKLIST",
    title: "Automatic operator and safety device test",
    description:
      "Verify operator actuation, speed, time delays, and safety sensors (presence, threshold, and REX) function as intended.",
    defaultRedFlag: true,
    featureTags: ["AUTOMATIC_OPERATORS", "COMMISSIONING"],
  },
  {
    id: "punch-028-003",
    phase: "PUNCH",
    discipline: "DIV28",
    type: "CHECKLIST",
    title: "Video coverage and recording verification",
    description:
      "Confirm cameras at openings provide the expected field-of-view and that recording, retention, and playback meet requirements.",
    defaultRedFlag: true,
    featureTags: ["CAMERA_SURVEILLANCE", "COMMISSIONING"],
  },
  {
    id: "punch-028-004",
    phase: "PUNCH",
    discipline: "DIV28",
    type: "CHECKLIST",
    title: "Intrusion arm/disarm and alarm test",
    description:
      "Test arming/disarming, door contacts, motions, and glassbreak devices for correct alarm conditions and reporting.",
    defaultRedFlag: true,
    featureTags: ["INTRUSION", "COMMISSIONING"],
  },
  {
    id: "punch-028-005",
    phase: "PUNCH",
    discipline: "DIV28",
    type: "CHECKLIST",
    title: "Egress release and fire alarm integration test",
    description:
      "Confirm that egress doors release correctly on fire alarm or emergency override and that delayed/controlled egress behaves per code.",
    defaultRedFlag: true,
    featureTags: [
      "CONTROLLED_EGRESS",
      "DELAYED_EGRESS",
      "FIRE_ALARM_INTEGRATION",
    ],
  },

  //
  // CLOSEOUT – DIV 28 DOCUMENTATION & TRAINING
  //
  {
    id: "closeout-028-001",
    phase: "CLOSEOUT",
    discipline: "DIV28",
    type: "DOCUMENT",
    title: "Deliver Div 28 as-built drawings and risers",
    description:
      "Provide final as-built device layouts, riser diagrams, and panel schedules reflecting field-verified conditions.",
    defaultRedFlag: false,
    featureTags: ["ACCESS_CONTROL", "CAMERA_SURVEILLANCE", "INTRUSION"],
  },
  {
    id: "closeout-028-002",
    phase: "CLOSEOUT",
    discipline: "DIV28",
    type: "DOCUMENT",
    title: "Export and document controller configurations",
    description:
      "Export controller configurations, schedules, and logic; store securely per customer policy and project requirements.",
    defaultRedFlag: true,
    featureTags: ["ACCESS_CONTROL", "COMMISSIONING"],
  },
  {
    id: "closeout-028-003",
    phase: "CLOSEOUT",
    discipline: "DIV28",
    type: "MEETING_NOTE",
    title: "Owner training session for security and access control",
    description:
      "Conduct training on day-to-day use, credential management, basic troubleshooting, and escalation procedures.",
    defaultRedFlag: false,
    featureTags: ["TRAINING", "ACCESS_CONTROL", "GENERAL_SECURITY"],
  },
  {
    id: "closeout-028-004",
    phase: "CLOSEOUT",
    discipline: "DIV28",
    type: "DOCUMENT",
    title: "Provide key/credential and role-based access summary",
    description:
      "Summarize how roles, groups, and credential types are mapped to areas and openings for future reference.",
    defaultRedFlag: false,
    featureTags: ["ACCESS_CONTROL", "KEYING_CONFIDENTIALITY"],
  },
  {
    id: "closeout-028-005",
    phase: "CLOSEOUT",
    discipline: "DIV28",
    type: "DOCUMENT",
    title: "Security and keying confidentiality notice",
    description:
      "Issue a confidentiality notice covering system details, keying, and access data, and confirm who is authorized to receive information.",
    defaultRedFlag: true,
    featureTags: ["KEYING_CONFIDENTIALITY", "GENERAL_SECURITY"],
  },
];

export function instantiateTasksForProject(params: {
  projectId: string;
  nowIso?: string;
}): PmTask[] {
  const { projectId, nowIso } = params;
  const now = nowIso ?? new Date().toISOString();

  return pmTaskTemplates.map((tmpl) => ({
    id: uuidv4(),
    projectId,
    openingId: null,
    phase: tmpl.phase,
    discipline: tmpl.discipline,
    type: tmpl.type,
    title: tmpl.title,
    description: tmpl.description,
    status: "NOT_STARTED",
    assigneeName: null,
    assigneeRole: null,
    dueDate: null,
    createdAt: now,
    updatedAt: now,
    redFlag: tmpl.defaultRedFlag,
    featureTags: tmpl.featureTags ?? [],
  }));
}
