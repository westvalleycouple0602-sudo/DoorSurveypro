# Replit Starter + Door & Frame Validation (US/Canada)

This repo includes:
- Self-healing + telemetry starter (FastAPI, Sentry, PostHog, repair worker, synthetic checks)
- Door & Frame **validation service** at `/validate` (US & Canada; swing, sliding, revolving, auto/manual)

## Quick start
1) `pip install -r requirements.txt`
2) `playwright install --with-deps`
3) Add Replit Secrets per `.env.example`
4) Click **Run** or: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`

### Try the validator
```bash
# The validator is mounted at /validate/validate
curl -X POST http://localhost:8000/validate/validate -H "Content-Type: application/json" --data @app/validation/sample_payload.json
```
Front-end validator: `public/validateScan.ts`
