// src/index_with_ui.ts
import express from "express";
import bodyParser from "body-parser";
import path from "path";
import { router as bomRouter } from "./server_route";
import { router as legacyBomRouter } from "./server_route"; // alias
import { routerPro } from "./server_route_pro";

const app = express();
app.use(bodyParser.json());
app.use("/output", express.static("output"));
app.use(express.static("public")); // <-- serve the UI
app.use(bomRouter);
app.use(routerPro);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`DoorSurvey AI server + UI on http://localhost:${PORT}`));