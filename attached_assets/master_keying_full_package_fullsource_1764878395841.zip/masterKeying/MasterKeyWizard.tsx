import React, { useState } from "react";
import type { MasterKeySystem, BrandConfig, Manufacturer } from "./masterKeying";
import { MasterKeyDiagram } from "./MasterKeyDiagram";
import { KeyDoorMatrix } from "./KeyDoorMatrix";
import { MasterKeyPdfPreviewCard } from "./MasterKeyPdfPreviewCard";
import { DoorAccessPanel } from "./DoorAccessPanel";
import { manufacturerPresets, applyManufacturerPresetToSystem } from "./manufacturerPresets";

type Tab = "CREATE" | "BRAND" | "PREVIEW";

interface MasterKeyWizardProps {
  initialSystem?: MasterKeySystem;
  onSaveInternal?: (system: MasterKeySystem) => void | Promise<void>;
  onExport?: (payload: any, view: "INTERNAL" | "CUSTOMER") => void | Promise<void>;
}

const defaultBrand: BrandConfig = {
  orgName: "DoorSurvey Pro",
  primaryColor: "#F97316",
  secondaryColor: "#0F172A",
  footerText: "© 2025 DoorSurvey Pro – CONFIDENTIAL",
  termsAndConditions:
    "This master key system diagram is confidential. Distribution is strictly limited.",
  watermarkText: "CONFIDENTIAL",
  hideBittingOnCustomerView: true,
};

export const MasterKeyWizard: React.FC<MasterKeyWizardProps> = ({
  initialSystem,
  onSaveInternal,
  onExport,
}) => {
  const [activeTab, setActiveTab] = useState<Tab>("CREATE");
  const [system, setSystem] = useState<MasterKeySystem | null>(initialSystem ?? null);
  const [brand, setBrand] = useState<BrandConfig>(initialSystem?.brand ?? defaultBrand);
  const [customerView, setCustomerView] = useState(false);
  const [previewTab, setPreviewTab] = useState<"DIAGRAM" | "MATRIX">("DIAGRAM");
  const [selectedDoorId, setSelectedDoorId] = useState<string | null>(null);

  const viewMode = customerView ? "CUSTOMER" : "INTERNAL";

  const ensureSystem = () => {
    if (system) return system;
    const now = new Date().toISOString();
    const base: MasterKeySystem = {
      id: "mks_" + Date.now().toString(36),
      name: "New Master Key System",
      facilityName: "Facility",
      manufacturer: "Other",
      keyways: [],
      nodes: [],
      doorOpenings: [],
      assignments: [],
      brand,
      createdAt: now,
      updatedAt: now,
    };
    setSystem(base);
    return base;
  };

  const handleCreateSystem = (name: string, facility: string) => {
    const now = new Date().toISOString();
    const base: MasterKeySystem = {
      id: "mks_" + Date.now().toString(36),
      name: name || "New Master Key System",
      facilityName: facility || "Facility",
      manufacturer: "Other",
      keyways: [],
      nodes: [],
      doorOpenings: [],
      assignments: [],
      brand,
      createdAt: now,
      updatedAt: now,
    };
    setSystem(base);
    setActiveTab("BRAND");
  };

  const handleBrandChange = (patch: Partial<BrandConfig>) => {
    setBrand((prev) => {
      const next = { ...(prev ?? defaultBrand), ...patch };
      setSystem((prevSys) =>
        prevSys ? { ...prevSys, brand: next, updatedAt: new Date().toISOString() } : prevSys
      );
      return next;
    });
  };

  const handleApplyPreset = (manufacturer: Manufacturer) => {
    setSystem((prevSys) => {
      const base = prevSys ?? ensureSystem();
      return applyManufacturerPresetToSystem(base, manufacturer);
    });
  };

  const effectiveSystem = system
    ? { ...system, brand }
    : null;

  const handleSave = async () => {
    if (!effectiveSystem || !onSaveInternal) return;
    await onSaveInternal(effectiveSystem);
  };

  const handleExportClick = async () => {
    if (!effectiveSystem || !onExport) return;
    const payload = effectiveSystem; // caller can run createExportPayload
    await onExport(payload, viewMode);
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex gap-2 text-sm">
        {(["CREATE", "BRAND", "PREVIEW"] as Tab[]).map((t) => (
          <button
            key={t}
            className={
              "px-3 py-1 rounded border " +
              (activeTab === t ? "bg-slate-900 text-white" : "bg-white text-slate-700")
            }
            onClick={() => setActiveTab(t)}
          >
            {t === "CREATE" ? "Create System" : t === "BRAND" ? "Branding" : "Preview / Export"}
          </button>
        ))}
      </div>

      <div className="border rounded-md p-4 bg-white space-y-4 text-sm">
        {activeTab === "CREATE" && (
          <div className="space-y-3">
            <p className="text-slate-600">
              Start a new master key system definition. You can import / seed keys later.
            </p>
            <CreateSystemForm onCreate={handleCreateSystem} />
          </div>
        )}

        {activeTab === "BRAND" && (
          <BrandPanel
            brand={brand}
            onChange={handleBrandChange}
            onApplyPreset={handleApplyPreset}
          />
        )}

        {activeTab === "PREVIEW" && effectiveSystem && (
          <PreviewPanel
            system={effectiveSystem}
            customerView={customerView}
            onCustomerViewChange={setCustomerView}
            previewTab={previewTab}
            onPreviewTabChange={setPreviewTab}
            selectedDoorId={selectedDoorId}
            onSelectedDoorChange={setSelectedDoorId}
            onSaveInternal={handleSave}
            onExport={handleExportClick}
          />
        )}

        {activeTab === "PREVIEW" && !effectiveSystem && (
          <p className="text-xs text-slate-500">
            No system loaded. Create or import a system first.
          </p>
        )}
      </div>
    </div>
  );
};

const CreateSystemForm: React.FC<{
  onCreate: (name: string, facility: string) => void;
}> = ({ onCreate }) => {
  const [name, setName] = useState("");
  const [facility, setFacility] = useState("");
  return (
    <div className="space-y-3">
      <label className="block">
        <span className="block mb-1 text-xs font-medium">System Name</span>
        <input
          className="border rounded px-2 py-1 w-full text-sm"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </label>
      <label className="block">
        <span className="block mb-1 text-xs font-medium">Facility Name</span>
        <input
          className="border rounded px-2 py-1 w-full text-sm"
          value={facility}
          onChange={(e) => setFacility(e.target.value)}
        />
      </label>
      <button
        type="button"
        className="px-3 py-1 bg-slate-900 text-white rounded text-xs"
        onClick={() => onCreate(name, facility)}
      >
        Create System
      </button>
    </div>
  );
};

const BrandPanel: React.FC<{
  brand: BrandConfig;
  onChange: (patch: Partial<BrandConfig>) => void;
  onApplyPreset: (m: Manufacturer) => void;
}> = ({ brand, onChange, onApplyPreset }) => {
  return (
    <div className="space-y-3 text-sm">
      <p className="text-slate-600">
        Configure branding (logo, colors, terms & conditions, confidentiality behavior).
      </p>

      <div className="mt-2 border rounded-md p-2 bg-slate-50 text-xs space-y-2">
        <div className="font-semibold">Manufacturer presets</div>
        <p className="text-slate-600">
          Pick a preset closest to your dominant key system vendor. This will adjust
          branding, default colors, and suggested keyways.
        </p>
        <div className="flex flex-col gap-1">
          {manufacturerPresets.map((p) => (
            <button
              type="button"
              key={p.label}
              className="text-left px-2 py-1 border rounded bg-white hover:bg-slate-100"
              onClick={() => onApplyPreset(p.manufacturer)}
            >
              <div className="font-semibold text-[11px]">{p.label}</div>
              <div className="text-[10px] text-slate-500">{p.description}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <label>
          <span className="block mb-1 text-xs font-medium">Organization Name</span>
          <input
            className="border rounded px-2 py-1 w-full text-sm"
            value={brand.orgName}
            onChange={(e) => onChange({ orgName: e.target.value })}
          />
        </label>
        <label>
          <span className="block mb-1 text-xs font-medium">Primary Color</span>
          <input
            type="color"
            className="border rounded px-2 py-1 w-full text-sm"
            value={brand.primaryColor}
            onChange={(e) => onChange({ primaryColor: e.target.value })}
          />
        </label>
        <label>
          <span className="block mb-1 text-xs font-medium">Secondary Color</span>
          <input
            type="color"
            className="border rounded px-2 py-1 w-full text-sm"
            value={brand.secondaryColor}
            onChange={(e) => onChange({ secondaryColor: e.target.value })}
          />
        </label>
        <label>
          <span className="block mb-1 text-xs font-medium">Logo URL</span>
          <input
            className="border rounded px-2 py-1 w-full text-sm"
            value={brand.logoUrl ?? ""}
            onChange={(e) => onChange({ logoUrl: e.target.value })}
          />
        </label>
      </div>

      <label className="block">
        <span className="block mb-1 text-xs font-medium">Watermark Text</span>
        <input
          className="border rounded px-2 py-1 w-full text-sm"
          value={brand.watermarkText ?? ""}
          onChange={(e) => onChange({ watermarkText: e.target.value })}
        />
      </label>
      <label className="block">
        <span className="block mb-1 text-xs font-medium">Footer Text</span>
        <input
          className="border rounded px-2 py-1 w-full text-sm"
          value={brand.footerText ?? ""}
          onChange={(e) => onChange({ footerText: e.target.value })}
        />
      </label>

      <label className="block">
        <span className="block mb-1 text-xs font-medium">Terms & Conditions</span>
        <textarea
          className="border rounded px-2 py-1 w-full min-h-[100px] text-xs"
          value={brand.termsAndConditions}
          onChange={(e) => onChange({ termsAndConditions: e.target.value })}
        />
      </label>

      <div className="space-y-1 text-xs">
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={brand.hideBittingOnCustomerView ?? false}
            onChange={(e) => onChange({ hideBittingOnCustomerView: e.target.checked })}
          />
          Hide bitting in customer-facing exports
        </label>
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={brand.hideKeywayOnCustomerView ?? false}
            onChange={(e) => onChange({ hideKeywayOnCustomerView: e.target.checked })}
          />
          Hide keyway info in customer-facing exports
        </label>
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={brand.hideManufacturerNamesOnCustomerView ?? false}
            onChange={(e) =>
              onChange({ hideManufacturerNamesOnCustomerView: e.target.checked })
            }
          />
          Hide manufacturer names in customer-facing exports
        </label>
      </div>
    </div>
  );
};

const PreviewPanel: React.FC<{
  system: MasterKeySystem;
  customerView: boolean;
  onCustomerViewChange: (val: boolean) => void;
  previewTab: "DIAGRAM" | "MATRIX";
  onPreviewTabChange: (tab: "DIAGRAM" | "MATRIX") => void;
  selectedDoorId: string | null;
  onSelectedDoorChange: (id: string | null) => void;
  onSaveInternal: () => void;
  onExport: () => void;
}> = ({
  system,
  customerView,
  onCustomerViewChange,
  previewTab,
  onPreviewTabChange,
  selectedDoorId,
  onSelectedDoorChange,
  onSaveInternal,
  onExport,
}) => {
  const viewMode = customerView ? "CUSTOMER" : "INTERNAL";
  return (
    <div className="space-y-3 text-sm">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold">
            {system.name} – {system.facilityName}
          </h3>
          <p className="text-xs text-slate-500">
            Master key visualization {customerView ? "(Customer View)" : "(Internal View)"}
          </p>
        </div>
        <div className="flex flex-col items-end gap-1">
          <label className="flex items-center gap-2 text-xs">
            <input
              type="checkbox"
              checked={customerView}
              onChange={(e) => onCustomerViewChange(e.target.checked)}
            />
            Customer-safe view (redact confidential details)
          </label>
          <div className="inline-flex border rounded overflow-hidden text-xs">
            <button
              type="button"
              className={
                "px-2 py-1 " +
                (previewTab === "DIAGRAM"
                  ? "bg-slate-900 text-white"
                  : "bg-white text-slate-700")
              }
              onClick={() => onPreviewTabChange("DIAGRAM")}
            >
              Diagram
            </button>
            <button
              type="button"
              className={
                "px-2 py-1 " +
                (previewTab === "MATRIX"
                  ? "bg-slate-900 text-white"
                  : "bg-white text-slate-700")
              }
              onClick={() => onPreviewTabChange("MATRIX")}
            >
              Matrix
            </button>
          </div>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-[minmax(0,1.2fr)_minmax(0,2fr)] items-start">
        <MasterKeyPdfPreviewCard system={system} view={viewMode} />
        <div className="space-y-3">
          {previewTab === "DIAGRAM" ? (
            <MasterKeyDiagram system={system} />
          ) : (
            <>
              <KeyDoorMatrix
                system={system}
                view={viewMode}
                onDoorClick={(doorId) => onSelectedDoorChange(doorId)}
              />
              {selectedDoorId && (
                <DoorAccessPanel
                  system={system}
                  doorId={selectedDoorId}
                  view={viewMode}
                  onClose={() => onSelectedDoorChange(null)}
                />
              )}
            </>
          )}
        </div>
      </div>

      <div className="flex gap-2 justify-end">
        <button
          type="button"
          className="px-3 py-1 border rounded"
          onClick={onSaveInternal}
        >
          Save Internally
        </button>
        <button
          type="button"
          className="px-3 py-1 bg-slate-900 text-white rounded"
          onClick={onExport}
        >
          Export {customerView ? "Customer View" : "Internal View"}
        </button>
      </div>
    </div>
  );
};
