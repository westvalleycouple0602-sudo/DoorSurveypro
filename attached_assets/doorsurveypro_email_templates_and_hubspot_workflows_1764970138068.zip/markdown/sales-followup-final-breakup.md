# sales-followup - final-breakup

**Subject:** Should I Keep Your File Open?

Hi {{FirstName}},  
I haven’t heard back, so I wanted to check whether you’d still like us to keep your project open.

If now isn’t the right time, no worries — just reply “pause” and we’ll put everything on hold.  
If you’re ready to move forward, reply “go” and we’ll take care of the rest.

Thanks again!
