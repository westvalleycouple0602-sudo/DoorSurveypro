
{ pkgs }: {
  deps = [
    pkgs.python311Full
    pkgs.cacert
  ];
}
