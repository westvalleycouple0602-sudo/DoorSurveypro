// src/div28/div28FormSchema.ts
import {
  AccessControlMode,
  AreaType,
  EgressType,
  GunDetectionIntent,
  IntrusionLevel,
  LockdownCoverage,
  RiskLevel,
  SurveillanceLevel,
  Div28SurveyAnswers,
} from "./div28Types";

export type FormFieldType = "select" | "boolean" | "textarea";

export interface Div28FormFieldOption {
  value: string;
  label: string;
}

export interface Div28FormField {
  id: keyof Div28SurveyAnswers;
  label: string;
  type: FormFieldType;
  helpText?: string;
  options?: Div28FormFieldOption[];
}

export interface Div28FormSection {
  id: string;
  title: string;
  description?: string;
  fields: Div28FormField[];
}

export const div28FormSections: Div28FormSection[] = [
  {
    id: "context",
    title: "Area & Risk Context",
    description:
      "Capture how this opening is used and how sensitive the adjoining space is.",
    fields: [
      {
        id: "areaType",
        label: "Area type",
        type: "select",
        options: [
          { value: "PUBLIC", label: "Public / Visitor area" },
          { value: "STAFF_ONLY", label: "Staff-only area" },
          { value: "CRITICAL_CARE", label: "Critical care / clinical" },
          { value: "PHARMACY", label: "Pharmacy / medication" },
          { value: "BEHAVIORAL_HEALTH", label: "Behavioral health unit" },
          { value: "IT_DATA_CENTER", label: "IT / data center" },
          { value: "ADMIN", label: "Administrative / back office" },
          { value: "OTHER", label: "Other / not listed" },
        ],
      },
      {
        id: "riskLevel",
        label: "Overall risk level for this opening",
        type: "select",
        options: [
          { value: "LOW", label: "Low" },
          { value: "MEDIUM", label: "Medium" },
          { value: "HIGH", label: "High" },
          { value: "CRITICAL", label: "Critical" },
        ],
      },
    ],
  },
  {
    id: "access-control",
    title: "Access Control & Usage",
    description:
      "Determine how access should be controlled and whether an audit trail is required.",
    fields: [
      {
        id: "accessControlMode",
        label: "How is / should access be controlled?",
        type: "select",
        options: [
          { value: "NONE", label: "No special control (free access)" },
          { value: "MECHANICAL_ONLY", label: "Mechanical key only" },
          { value: "BADGE_CARD", label: "Badge / card" },
          { value: "PIN_KEYPAD", label: "PIN keypad only" },
          { value: "BADGE_PLUS_PIN", label: "Badge + PIN (2-factor)" },
          { value: "MOBILE_CREDENTIAL", label: "Mobile credential" },
        ],
      },
      {
        id: "requiresAuditTrail",
        label: "Audit trail needed (who used the door and when)?",
        type: "boolean",
        helpText: "If yes, access control or logging system is recommended.",
      },
      {
        id: "scheduledLockUnlock",
        label: "Should lock/unlock follow a schedule (e.g., business hours)?",
        type: "boolean",
      },
    ],
  },
  {
    id: "egress",
    title: "Egress & Life Safety",
    description:
      "Capture egress type and whether controlled/delayed egress is desired.",
    fields: [
      {
        id: "egressType",
        label: "Egress type for this opening",
        type: "select",
        options: [
          { value: "FREE_EGRESS", label: "Free egress (typical)" },
          { value: "CONTROLLED_EGRESS", label: "Controlled egress" },
          { value: "DELAYED_EGRESS", label: "Delayed egress" },
          {
            value: "SPECIAL_LOCKING_ARRANGEMENT",
            label: "Special locking arrangement",
          },
        ],
      },
      {
        id: "unsureAboutEgressCode",
        label: "Uncertain about egress code requirements here",
        type: "boolean",
        helpText:
          "Flag this if the surveyor or customer is unsure; it will trigger engineering review.",
      },
    ],
  },
  {
    id: "automation",
    title: "Door Automation & Accessibility",
    description:
      "Determine whether automatic operation is recommended for traffic, ADA, or infection control.",
    fields: [
      {
        id: "heavyOrHighTraffic",
        label: "Heavy or high-traffic opening",
        type: "boolean",
      },
      {
        id: "adaPriority",
        label: "ADA / accessibility is a priority at this opening",
        type: "boolean",
      },
      {
        id: "infectionControlPriority",
        label: "Touchless / infection control is a priority",
        type: "boolean",
      },
    ],
  },
  {
    id: "monitoring",
    title: "Monitoring, Surveillance & Lockdown",
    description:
      "Capture monitoring, intrusion, and lockdown expectations for the opening.",
    fields: [
      {
        id: "surveillanceLevel",
        label: "Video surveillance at this opening",
        type: "select",
        options: [
          { value: "NONE", label: "No dedicated camera" },
          { value: "LOCAL_CAMERA", label: "Local camera at opening" },
          {
            value: "EXISTING_VIDEO_INTEGRATION",
            label: "Tie into existing video system",
          },
          { value: "ANALYTICS_READY", label: "Analytics / AI-ready coverage" },
        ],
      },
      {
        id: "intrusionLevel",
        label: "Intrusion detection at this opening",
        type: "select",
        options: [
          { value: "NONE", label: "None" },
          {
            value: "DOOR_CONTACT_ONLY",
            label: "Door contact only (open/close monitoring)",
          },
          {
            value: "DOOR_PLUS_MOTION",
            label: "Door contact + motion detection",
          },
          {
            value: "DOOR_PLUS_GLASSBREAK",
            label: "Door contact + glassbreak / impact detection",
          },
        ],
      },
      {
        id: "lockdownCoverage",
        label: "Lockdown behavior for this opening",
        type: "select",
        options: [
          { value: "NONE", label: "Not part of lockdown" },
          { value: "LOCAL_ONLY", label: "Local room/area lockdown only" },
          { value: "ZONE_LOCKDOWN", label: "Part of a zone lockdown" },
          {
            value: "BUILDING_LOCKDOWN",
            label: "Part of building-wide lockdown sequences",
          },
        ],
      },
    ],
  },
  {
    id: "threat-detection",
    title: "Threat / Gun Detection Intent",
    description:
      "Capture whether the client is interested in or requires threat detection capabilities.",
    fields: [
      {
        id: "gunDetectionIntent",
        label: "Threat / gun detection requirements",
        type: "select",
        options: [
          { value: "NONE", label: "No specific requirement" },
          { value: "INTERESTED", label: "Interested / future consideration" },
          { value: "REQUIRED", label: "Required as part of security strategy" },
        ],
      },
    ],
  },
  {
    id: "notes",
    title: "Additional Notes",
    description: "Free-form notes to capture special conditions or requests.",
    fields: [
      {
        id: "notes",
        label: "Surveyor / customer notes",
        type: "textarea",
        helpText:
          "Include any special conditions, existing systems, or coordination notes.",
      },
    ],
  },
];

export const defaultDiv28SurveyAnswers = (
  openingId: string
): Div28SurveyAnswers => ({
  openingId,
  areaType: "PUBLIC" as AreaType,
  riskLevel: "LOW" as RiskLevel,
  accessControlMode: "NONE" as AccessControlMode,
  requiresAuditTrail: false,
  scheduledLockUnlock: false,
  egressType: "FREE_EGRESS" as EgressType,
  unsureAboutEgressCode: false,
  heavyOrHighTraffic: false,
  adaPriority: false,
  infectionControlPriority: false,
  surveillanceLevel: "NONE" as SurveillanceLevel,
  intrusionLevel: "NONE" as IntrusionLevel,
  lockdownCoverage: "NONE" as LockdownCoverage,
  gunDetectionIntent: "NONE" as GunDetectionIntent,
  notes: "",
});
