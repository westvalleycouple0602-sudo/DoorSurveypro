// backend/src/openings/openingsRepository.ts
import { eq } from "drizzle-orm";
import { db } from "../db/client";
import { openings } from "../db/schema";
import {
  OpeningCreatePayload,
  OpeningUpdatePayload,
  OpeningRecord,
} from "./openingDtos";

export async function getOpeningById(id: string): Promise<OpeningRecord | null> {
  if (!db) throw new Error("DB is not initialized");
  const rows = await db.select().from(openings).where(eq(openings.id, id));
  if (!rows.length) return null;
  const row = rows[0] as any;
  return {
    id: row.id,
    projectId: row.projectId,
    openingNumber: row.openingNumber,
    name: row.name ?? undefined,
    locationDescription: row.locationDescription ?? undefined,
    doorFunction: row.doorFunction,
    fireRating: row.fireRating,
    frameMaterial: row.frameMaterial,
    hand: row.hand ?? undefined,
    roughOpeningWidthMm: row.roughOpeningWidthMm
      ? Number(row.roughOpeningWidthMm)
      : undefined,
    roughOpeningHeightMm: row.roughOpeningHeightMm
      ? Number(row.roughOpeningHeightMm)
      : undefined,
    leafWidthMm: row.leafWidthMm ? Number(row.leafWidthMm) : undefined,
    leafHeightMm: row.leafHeightMm ? Number(row.leafHeightMm) : undefined,
    hardwareSetId: row.hardwareSetId ?? undefined,
    div28Survey: row.div28Survey as any,
    div28Opportunity: (row.div28Opportunity as any) ?? null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export async function createOpening(
  id: string,
  nowIso: string,
  payload: OpeningCreatePayload & { div28Opportunity: any }
): Promise<OpeningRecord> {
  if (!db) throw new Error("DB is not initialized");
  const now = new Date(nowIso);
  await (db as any).insert(openings).values({
    id,
    projectId: payload.projectId,
    openingNumber: payload.openingNumber,
    name: payload.name ?? null,
    locationDescription: payload.locationDescription ?? null,
    doorFunction: payload.doorFunction,
    fireRating: payload.fireRating,
    frameMaterial: payload.frameMaterial,
    hand: payload.hand ?? null,
    roughOpeningWidthMm: payload.roughOpeningWidthMm
      ? String(payload.roughOpeningWidthMm)
      : null,
    roughOpeningHeightMm: payload.roughOpeningHeightMm
      ? String(payload.roughOpeningHeightMm)
      : null,
    leafWidthMm: payload.leafWidthMm ? String(payload.leafWidthMm) : null,
    leafHeightMm: payload.leafHeightMm ? String(payload.leafHeightMm) : null,
    hardwareSetId: payload.hardwareSetId ?? null,
    div28Survey: payload.div28Survey as any,
    div28Opportunity: payload.div28Opportunity as any,
    createdAt: now,
    updatedAt: now,
  });

  const opening = await getOpeningById(id);
  if (!opening) throw new Error("Failed to read opening after insert");
  return opening;
}

export async function updateOpening(
  id: string,
  nowIso: string,
  payload: OpeningUpdatePayload & {
    div28SurveyEffective: any;
    div28Opportunity: any;
  }
): Promise<OpeningRecord> {
  if (!db) throw new Error("DB is not initialized");
  const existing = await getOpeningById(id);
  if (!existing) throw new Error("Opening not found");

  const mergedDiv8 = {
    openingNumber: payload.div8?.openingNumber ?? existing.openingNumber,
    name: payload.div8?.name ?? existing.name,
    locationDescription:
      payload.div8?.locationDescription ?? existing.locationDescription,
    doorFunction: payload.div8?.doorFunction ?? existing.doorFunction,
    fireRating: payload.div8?.fireRating ?? existing.fireRating,
    frameMaterial: payload.div8?.frameMaterial ?? existing.frameMaterial,
    hand: payload.div8?.hand ?? existing.hand,
    roughOpeningWidthMm:
      payload.div8?.roughOpeningWidthMm ?? existing.roughOpeningWidthMm,
    roughOpeningHeightMm:
      payload.div8?.roughOpeningHeightMm ?? existing.roughOpeningHeightMm,
    leafWidthMm: payload.div8?.leafWidthMm ?? existing.leafWidthMm,
    leafHeightMm: payload.div8?.leafHeightMm ?? existing.leafHeightMm,
    hardwareSetId: payload.div8?.hardwareSetId ?? existing.hardwareSetId,
  };

  const now = new Date(nowIso);

  await (db as any)
    .update(openings)
    .set({
      openingNumber: mergedDiv8.openingNumber,
      name: mergedDiv8.name ?? null,
      locationDescription: mergedDiv8.locationDescription ?? null,
      doorFunction: mergedDiv8.doorFunction,
      fireRating: mergedDiv8.fireRating,
      frameMaterial: mergedDiv8.frameMaterial,
      hand: mergedDiv8.hand ?? null,
      roughOpeningWidthMm: mergedDiv8.roughOpeningWidthMm
        ? String(mergedDiv8.roughOpeningWidthMm)
        : null,
      roughOpeningHeightMm: mergedDiv8.roughOpeningHeightMm
        ? String(mergedDiv8.roughOpeningHeightMm)
        : null,
      leafWidthMm: mergedDiv8.leafWidthMm
        ? String(mergedDiv8.leafWidthMm)
        : null,
      leafHeightMm: mergedDiv8.leafHeightMm
        ? String(mergedDiv8.leafHeightMm)
        : null,
      hardwareSetId: mergedDiv8.hardwareSetId ?? null,
      div28Survey: payload.div28SurveyEffective as any,
      div28Opportunity: payload.div28Opportunity as any,
      updatedAt: now,
    })
    .where(eq(openings.id, id));

  const updated = await getOpeningById(id);
  if (!updated) throw new Error("Failed to read opening after update");
  return updated;
}
