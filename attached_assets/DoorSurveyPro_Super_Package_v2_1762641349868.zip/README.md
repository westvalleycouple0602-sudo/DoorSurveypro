# DoorSurvey Pro — Super Package (All-in-One)

## What's included
- **Backend** (Express + Drizzle + RBAC + OIDC + S3/R2 presigned URLs + Webhooks + Audit + Rate limit)
- **Cloudflare Worker** thumbnailer scaffold
- **Postman collection**
- **Frontend sample** component
- **Docker Compose** (Postgres + API + MinIO) and **seed.sql**

## Quick start
```bash
docker compose up -d
docker compose exec api sh -lc 'npm i && npm run migrate:generate && npm run migrate:push'
psql "postgres://dsp:dsp@localhost:5432/dsp" -f seed.sql
curl http://localhost:3001/health
# Login: http://localhost:3001/auth/login
```


## Ultra component integration
1) Copy `frontend-components/Ultra/FloorPlanViewer_PinDrop_Ultra.tsx` into your app (e.g., `src/components/`).
2) Install peer deps in your frontend (React + shadcn/ui + lucide-react + `jspdf` for bulk PDF).
   ```bash
   npm i jspdf lucide-react
   # shadcn/ui setup per your stack if not already installed
   ```
3) Use the provided helper:
   ```ts
   import { apiFetch } from "../frontend-components/apiClient";
   ```
4) Set auth headers on your fetches (`Authorization: Bearer <token>`, `X-Tenant-Id: <tenant>`).
5) Try the sample under `frontend-components/next-sample/` for a quick Next.js page.
