# proposal - engineering-notes

**Subject:** Engineering Review for {{ProjectName}} – Please Review

Hi {{FirstName}},  
Our engineering team has completed their compliance review.  
Your proposal now includes:

- Fire rating requirements  
- ADA / IBC compliance status  
- Hardware compatibility checks  
- Any red flags that need addressing  

Please review at your earliest convenience.
