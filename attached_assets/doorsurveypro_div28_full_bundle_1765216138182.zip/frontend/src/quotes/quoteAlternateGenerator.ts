// frontend/src/quotes/quoteAlternateGenerator.ts
import type {
  ApiOpeningRecord,
  ApiProposalPayload,
} from "../api/openingsClientProposals";

export interface AlternatePricingAdjustment {
  percentDelta: number;
  label: string;
  notes?: string;
}

export interface AlternateOptionText {
  heading: string;
  bodyPlain: string;
  bodyMarkdown: string;
}

export function buildAlternateOptionText(params: {
  opening: ApiOpeningRecord;
  proposal: ApiProposalPayload | null;
  baseTotal: number;
  adjustment: AlternatePricingAdjustment;
}): AlternateOptionText {
  const { opening, proposal, baseTotal, adjustment } = params;
  const openingLabel = opening.name ?? `Opening ${opening.openingNumber}`;
  const altFactor = 1 + adjustment.percentDelta / 100;
  const altTotal = Math.round(baseTotal * altFactor * 100) / 100;

  const heading = `${openingLabel} – Alternate Option (${adjustment.label})`;

  const plainLines: string[] = [];
  plainLines.push(heading);
  plainLines.push("");
  plainLines.push(
    `Base option estimated total: $${baseTotal.toFixed(2)}`
  );
  plainLines.push(
    `Alternate option (${adjustment.percentDelta >= 0 ? "+" : ""}${
      adjustment.percentDelta
    }%) estimated total: $${altTotal.toFixed(2)}`
  );
  plainLines.push("");

  if (proposal) {
    plainLines.push("Scope Notes:");
    plainLines.push("------------");
    plainLines.push(
      "This alternate uses the same core Div 8 scope and adjusts Div 28 scope/level as follows:"
    );
    plainLines.push("");
    plainLines.push(proposal.summary);
    plainLines.push("");
  }

  if (adjustment.notes) {
    plainLines.push("Additional Notes:");
    plainLines.push("---------------");
    plainLines.push(adjustment.notes);
  }

  const bodyPlain = plainLines.join("\n");

  const mdLines: string[] = [];
  mdLines.push(`# ${heading}`);
  mdLines.push("");
  mdLines.push(
    `**Base option estimated total:** $${baseTotal.toFixed(2)}`
  );
  mdLines.push(
    `**Alternate option (${adjustment.percentDelta >= 0 ? "+" : ""}${
      adjustment.percentDelta
    }%) estimated total:** $${altTotal.toFixed(2)}`
  );
  mdLines.push("");

  if (proposal) {
    mdLines.push("## Scope Notes");
    mdLines.push("");
    mdLines.push(
      "This alternate uses the same core Div 8 scope and adjusts Div 28 scope/level as follows:"
    );
    mdLines.push("");
    mdLines.push(proposal.summary);
    mdLines.push("");
  }

  if (adjustment.notes) {
    mdLines.push("## Additional Notes");
    mdLines.push("");
    mdLines.push(adjustment.notes);
  }

  const bodyMarkdown = mdLines.join("\n");

  return {
    heading,
    bodyPlain,
    bodyMarkdown,
  };
}
