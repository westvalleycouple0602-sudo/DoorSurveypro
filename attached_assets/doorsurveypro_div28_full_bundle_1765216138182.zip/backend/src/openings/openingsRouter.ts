// backend/src/openings/openingsRouter.ts
import express from "express";
import { v4 as uuidv4 } from "uuid";
import {
  OpeningCreatePayload,
  OpeningUpdatePayload,
  OpeningWithTasksAndProposalResponse,
} from "./openingDtos";
import { computeDiv28Opportunity } from "../div28/div28OpportunityScoring";
import { buildDiv28TasksForOpening } from "../div28/div28PmTasks";
import { buildOpeningProposalPackage } from "../div28/div28ProposalSnippets";
import {
  createOpening,
  getOpeningById,
  updateOpening,
} from "./openingsRepository";

const router = express.Router();

router.get("/openings/:id", async (req, res) => {
  try {
    const opening = await getOpeningById(req.params.id);
    if (!opening) {
      return res.status(404).json({ error: "Opening not found" });
    }
    res.json(opening);
  } catch (error: any) {
    console.error(error);
    res.status(500).json({ error: error.message ?? "Failed to fetch opening" });
  }
});

router.post<{}, OpeningWithTasksAndProposalResponse, OpeningCreatePayload>(
  "/openings",
  async (req, res) => {
    try {
      const payload = req.body;
      const nowIso = new Date().toISOString();
      const id = uuidv4();

      const div28Opportunity = computeDiv28Opportunity(payload.div28Survey);

      const opening = await createOpening(id, nowIso, {
        ...payload,
        div28Opportunity,
      });

      const tasks = buildDiv28TasksForOpening(
        payload.projectId,
        opening.id,
        div28Opportunity
      );

      const openingLabel =
        opening.name || `Opening ${opening.openingNumber}`;

      const proposalPackage = buildOpeningProposalPackage(
        opening.id,
        openingLabel,
        div28Opportunity
      );

      res.status(201).json({
        opening,
        div28Tasks: tasks,
        proposal: {
          baseOptionText: proposalPackage.baseOptionText,
          upgradeBlocks: proposalPackage.upgradeOptions.map((block) => ({
            id: block.id,
            title: block.title,
            body: block.body,
            appliesToFeatures: block.appliesToFeatures,
          })),
          summary: proposalPackage.summary,
        },
      });
    } catch (error: any) {
      console.error(error);
      res
        .status(500)
        .json({ error: error.message ?? "Failed to create opening" });
    }
  }
);

router.put<{}, OpeningWithTasksAndProposalResponse, OpeningUpdatePayload>(
  "/openings/:id",
  async (req, res) => {
    try {
      const existing = await getOpeningById(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Opening not found" });
      }

      const payload = req.body;
      const nowIso = new Date().toISOString();

      const effectiveSurvey = payload.div28Survey ?? existing.div28Survey;
      const div28Opportunity = computeDiv28Opportunity(effectiveSurvey);

      const updated = await updateOpening(existing.id, nowIso, {
        ...payload,
        div28SurveyEffective: effectiveSurvey,
        div28Opportunity,
      } as any);

      const tasks = buildDiv28TasksForOpening(
        updated.projectId,
        updated.id,
        div28Opportunity
      );

      const openingLabel =
        updated.name || `Opening ${updated.openingNumber}`;

      const proposalPackage = buildOpeningProposalPackage(
        updated.id,
        openingLabel,
        div28Opportunity
      );

      res.json({
        opening: updated,
        div28Tasks: tasks,
        proposal: {
          baseOptionText: proposalPackage.baseOptionText,
          upgradeBlocks: proposalPackage.upgradeOptions.map((block) => ({
            id: block.id,
            title: block.title,
            body: block.body,
            appliesToFeatures: block.appliesToFeatures,
          })),
          summary: proposalPackage.summary,
        },
      });
    } catch (error: any) {
      console.error(error);
      res
        .status(500)
        .json({ error: error.message ?? "Failed to update opening" });
    }
  }
);

export default router;
