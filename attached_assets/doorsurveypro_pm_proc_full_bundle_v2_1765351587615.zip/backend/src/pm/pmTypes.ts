// backend/src/pm/pmTypes.ts
export type PmPhase =
  | "PRE_CONTRACT"
  | "CONTRACT_EXECUTED"
  | "SUBMITTALS"
  | "PROCUREMENT"
  | "INSTALLATION"
  | "PUNCH"
  | "CLOSEOUT";

export type PmDiscipline =
  | "DIV8"
  | "DIV28"
  | "STRUCTURAL"
  | "ELECTRICAL"
  | "GENERAL"
  | "OTHER";

export type PmTaskStatus =
  | "NOT_STARTED"
  | "IN_PROGRESS"
  | "HOLD"
  | "COMPLETE"
  | "VOID";

export type PmTaskType =
  | "CHECKLIST"
  | "DOCUMENT"
  | "RFI"
  | "SUBMITTAL"
  | "MEETING_NOTE"
  | "CHANGE_ORDER"
  | "PROCUREMENT"
  | "FIELD_ISSUE";

// Tags to slice PM tasks by Div 28 scope
export type PmFeatureTag =
  | "ACCESS_CONTROL"
  | "AUTOMATIC_OPERATORS"
  | "CONTROLLED_EGRESS"
  | "DELAYED_EGRESS"
  | "CAMERA_SURVEILLANCE"
  | "INTRUSION"
  | "LOCKDOWN"
  | "NETWORK_IT"
  | "FIRE_ALARM_INTEGRATION"
  | "CLOUD_LICENSES"
  | "POWER_SUPPLIES"
  | "COMMISSIONING"
  | "TRAINING"
  | "KEYING_CONFIDENTIALITY"
  | "GENERAL_SECURITY";

export interface PmTask {
  id: string;
  projectId: string;
  openingId?: string | null;
  phase: PmPhase;
  discipline: PmDiscipline;
  type: PmTaskType;
  title: string;
  description?: string | null;
  status: PmTaskStatus;
  assigneeName?: string | null;
  assigneeRole?: string | null;
  dueDate?: string | null;
  createdAt: string;
  updatedAt: string;
  redFlag: boolean;
  featureTags?: PmFeatureTag[];
}

export interface PmTimelineMilestone {
  id: string;
  projectId: string;
  label: string;
  phase: PmPhase;
  targetDate?: string | null;
  completedDate?: string | null;
}
