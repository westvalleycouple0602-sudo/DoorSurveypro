# Frontend – PM Board & Procurement Checklist

This frontend bundle provides:

- A PM Kanban-style board component (`PmBoard`) for project phases
- A procurement red-flag checklist panel (`ProcurementChecklistPanel`)

Both components are written in React and are compatible with a Vite + Tailwind
+ Shadcn/TanStack-style environment used by DoorSurvey Pro.

You can import and mount these components inside your existing layout.
