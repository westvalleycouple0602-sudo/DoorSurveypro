# scheduling - schedule-survey

**Subject:** Schedule Your Door Opening Survey

Hi {{FirstName}},  
Your project is ready for scheduling.  
Please choose a time that works best: {{SchedulingLink}}

Our technician will perform:  
- Door/Frame measurements  
- AR/LiDAR scanning  
- Hardware identification  
- Compliance checks  

Please confirm if site access or credentials are required.
