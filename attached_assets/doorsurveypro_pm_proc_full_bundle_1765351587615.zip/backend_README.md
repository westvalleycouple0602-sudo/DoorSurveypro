# Backend – PM & Procurement Modules (Monolith-Friendly)

This backend bundle provides:

- PM task templates and a simple in-memory PM API
- Procurement grouping engine by manufacturer (Div 8 + Div 28)
- Express server exposing `/api/pm/*` and `/api/procurement/*` routes

## Quick start

```bash
cd backend
npm install express cors body-parser uuid
# plus your TypeScript tooling if needed
ts-node src/server.ts
```

In Replit, set the entry to `backend/src/server.ts` or compile to JS first.
