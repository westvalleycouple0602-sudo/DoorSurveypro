// backend/src/div28/div28OpportunityScoring.ts
import {
  Div28Feature,
  Div28OpportunitySummary,
  Div28SurveyAnswers,
} from "./div28Types";

const baseWeights: Record<Div28Feature, number> = {
  ACCESS_CONTROL: 20,
  DOOR_AUTOMATION: 10,
  CONTROLLED_EGRESS: 25,
  DELAYED_EGRESS: 20,
  SURVEILLANCE: 15,
  INTRUSION_DETECTION: 15,
  GUN_DETECTION_READY: 10,
  LOCKDOWN_CONTROL: 20,
};

function riskMultiplier(risk: Div28SurveyAnswers["riskLevel"]): number {
  switch (risk) {
    case "LOW":
      return 0.6;
    case "MEDIUM":
      return 0.9;
    case "HIGH":
      return 1.1;
    case "CRITICAL":
      return 1.3;
    default:
      return 1.0;
  }
}

function clampScore(score: number): number {
  return Math.max(0, Math.min(100, Math.round(score)));
}

function tierFromScore(score: number): Div28OpportunitySummary["tier"] {
  if (score <= 0) return "NONE";
  if (score < 25) return "LOW";
  if (score < 60) return "MEDIUM";
  return "HIGH";
}

export function computeDiv28Opportunity(
  answers: Div28SurveyAnswers
): Div28OpportunitySummary {
  const features: Div28Feature[] = [];
  const warnings: string[] = [];
  let score = 0;

  const mult = riskMultiplier(answers.riskLevel);

  if (
    answers.accessControlMode !== "NONE" &&
    answers.accessControlMode !== "MECHANICAL_ONLY"
  ) {
    features.push("ACCESS_CONTROL");
    score += baseWeights.ACCESS_CONTROL * mult;
    if (answers.requiresAuditTrail) score += 5 * mult;
    if (answers.scheduledLockUnlock) score += 5 * mult;
  }

  if (answers.heavyOrHighTraffic || answers.adaPriority) {
    features.push("DOOR_AUTOMATION");
    score += baseWeights.DOOR_AUTOMATION * mult;
    if (answers.infectionControlPriority) score += 5 * mult;
  }

  if (answers.egressType === "CONTROLLED_EGRESS") {
    features.push("CONTROLLED_EGRESS");
    score += baseWeights.CONTROLLED_EGRESS * mult;
    warnings.push(
      "Controlled egress requires careful code review and AHJ approval, especially in healthcare occupancies."
    );
  }

  if (answers.egressType === "DELAYED_EGRESS") {
    features.push("DELAYED_EGRESS");
    score += baseWeights.DELAYED_EGRESS * mult;
    warnings.push(
      "Delayed egress is subject to strict time, signage, and release requirements; coordinate with AHJ."
    );
  }

  if (answers.unsureAboutEgressCode) {
    warnings.push(
      "Surveyor or customer indicated uncertainty about egress requirements – recommend engineering review."
    );
  }

  if (answers.surveillanceLevel !== "NONE") {
    features.push("SURVEILLANCE");
    score += baseWeights.SURVEILLANCE * mult;
  }

  if (answers.intrusionLevel !== "NONE") {
    features.push("INTRUSION_DETECTION");
    score += baseWeights.INTRUSION_DETECTION * mult;
  }

  if (answers.gunDetectionIntent === "INTERESTED") {
    features.push("GUN_DETECTION_READY");
    score += baseWeights.GUN_DETECTION_READY * mult;
  } else if (answers.gunDetectionIntent === "REQUIRED") {
    features.push("GUN_DETECTION_READY");
    score += baseWeights.GUN_DETECTION_READY * mult + 5 * mult;
    warnings.push(
      "Customer indicated gun/threat detection is REQUIRED – ensure video coverage and analytics-ready design."
    );
  }

  if (answers.lockdownCoverage !== "NONE") {
    features.push("LOCKDOWN_CONTROL");
    score += baseWeights.LOCKDOWN_CONTROL * mult;
  }

  const uniqueFeatures = Array.from(new Set(features));
  const finalScore = clampScore(score);
  const tier = tierFromScore(finalScore);

  const summaryLines: string[] = [];

  if (tier === "NONE") {
    summaryLines.push("No explicit Div 28 requirements identified for this opening.");
  } else {
    summaryLines.push(
      `This opening has a ${tier.toLowerCase()} Div 28 opportunity with a computed score of ${finalScore}.`
    );
    if (uniqueFeatures.includes("ACCESS_CONTROL")) {
      summaryLines.push("• Access control is recommended for this opening.");
    }
    if (uniqueFeatures.includes("DOOR_AUTOMATION")) {
      summaryLines.push(
        "• Consider automatic operation driven by ADA, traffic, or infection control."
      );
    }
    if (uniqueFeatures.includes("CONTROLLED_EGRESS")) {
      summaryLines.push(
        "• Opening is a candidate for controlled egress – coordinate closely with code requirements."
      );
    }
    if (uniqueFeatures.includes("DELAYED_EGRESS")) {
      summaryLines.push(
        "• Delayed egress hardware may help with elopement/theft while preserving code compliance."
      );
    }
    if (uniqueFeatures.includes("SURVEILLANCE")) {
      summaryLines.push(
        "• Video surveillance at this opening would improve visibility and incident review."
      );
    }
    if (uniqueFeatures.includes("INTRUSION_DETECTION")) {
      summaryLines.push(
        "• Intrusion detection (door contact/motion/etc.) is advisable after hours."
      );
    }
    if (uniqueFeatures.includes("LOCKDOWN_CONTROL")) {
      summaryLines.push(
        "• This opening should participate in a local or building-wide lockdown strategy."
      );
    }
    if (uniqueFeatures.includes("GUN_DETECTION_READY")) {
      summaryLines.push(
        "• Customer expressed interest in gun/threat detection – design for analytics-ready coverage."
      );
    }
  }

  if (answers.notes) {
    summaryLines.push(`Surveyor notes: ${answers.notes}`);
  }

  return {
    openingId: answers.openingId,
    score: finalScore,
    tier,
    recommendedFeatures: uniqueFeatures,
    narrativeSummary: summaryLines.join("\n"),
    warnings,
  };
}
