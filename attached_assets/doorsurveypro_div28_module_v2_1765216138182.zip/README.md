# DoorSurvey Pro – Div 28 Integration Module (v2)

This package extends DoorSurvey Pro with Division 28 (Electronic Safety & Security)
awareness at the opening level, including:

- Strong typed models for Div 28 survey answers and opportunity summaries.
- A scoring engine to rate Div 28 opportunity per opening.
- Proposal text helpers for Div 8 + 28 upgrade options.
- A JSON-like form schema + React form component for the "Security & Controls" tab.
- Project management task templates to drive Div 28 coordination work.

## Files

- `src/div28/div28Types.ts`  
  Core enums and interfaces for survey answers, features, and opportunity summaries.

- `src/div28/div28OpportunityScoring.ts`  
  `computeDiv28Opportunity()` turns survey answers into a score, tier, feature list,
  narrative summary, and warnings.

- `src/div28/div28ProposalSnippets.ts`  
  `buildOpeningProposalPackage()` generates base-option text and upgrade blocks for
  proposals and export/print.

- `src/div28/div28FormSchema.ts`  
  JSON-like schema describing sections/fields for the Div 28 survey UI, plus
  `defaultDiv28SurveyAnswers(openingId)` helper.

- `src/div28/Div28SurveyForm.tsx`  
  A small React component that renders the Div 28 form using the schema. Designed
  to drop into your existing opening-survey layout.

- `src/div28/div28PmTasks.ts`  
  Div 28 project-management task templates and `buildDiv28TasksForOpening()` helper
  to generate coordination tasks for engineering, PM, and security integrators.

## Basic wiring

1. **UI**  
   - For each opening, initialize `Div28SurveyAnswers` via
     `defaultDiv28SurveyAnswers(openingId)` and render `<Div28SurveyForm />`
     with `value` and `onChange` props.

2. **Scoring**  
   - When an opening survey is saved or a quote is generated, call
     `computeDiv28Opportunity(answers)` and store the result on the opening
     record or derived quote data.

3. **Proposals**  
   - Use `buildOpeningProposalPackage(openingId, openingLabel, opportunity)`
     to populate your proposal/export with base hardware text and Div 28
     upgrade options.

4. **Project Management**  
   - For each opening (or only those with MEDIUM/HIGH tiers), call
     `buildDiv28TasksForOpening(projectId, openingId, opportunity)` and insert
     the resulting tasks into your PM pipeline with appropriate assignees.

You can adjust scoring weights, text copy, and task templates to match your
verticals (healthcare, education, commercial, government) and manufacturer
ecosystems over time.
