// frontend/src/api/openingsClientProposals.ts
export interface ApiOpeningDiv8Core {
  openingNumber: string;
  name?: string;
  locationDescription?: string;
  doorFunction: string;
  fireRating: string;
  frameMaterial: string;
  hand?: string;
  roughOpeningWidthMm?: number;
  roughOpeningHeightMm?: number;
  leafWidthMm?: number;
  leafHeightMm?: number;
  hardwareSetId?: string;
}

export interface ApiDiv28Survey {
  openingId: string;
  areaType: string;
  riskLevel: string;
  accessControlMode: string;
  requiresAuditTrail: boolean;
  scheduledLockUnlock: boolean;
  egressType: string;
  unsureAboutEgressCode: boolean;
  heavyOrHighTraffic: boolean;
  adaPriority: boolean;
  infectionControlPriority: boolean;
  surveillanceLevel: string;
  intrusionLevel: string;
  lockdownCoverage: string;
  gunDetectionIntent: string;
  notes?: string;
}

export interface ApiDiv28Opportunity {
  openingId: string;
  score: number;
  tier: "NONE" | "LOW" | "MEDIUM" | "HIGH";
  recommendedFeatures: string[];
  narrativeSummary: string;
  warnings: string[];
}

export interface ApiOpeningRecord extends ApiOpeningDiv8Core {
  id: string;
  projectId: string;
  createdAt: string;
  updatedAt: string;
  div28Survey: ApiDiv28Survey;
  div28Opportunity: ApiDiv28Opportunity | null;
}

export interface ApiGeneratedDiv28Task {
  id: string;
  projectId: string;
  openingId: string;
  feature: string;
  title: string;
  description: string;
  assigneeRole: string;
  suggestedDueOffsetDays: number;
}

export interface ApiProposalBlock {
  id: string;
  title: string;
  body: string;
  appliesToFeatures: string[];
}

export interface ApiProposalPayload {
  baseOptionText: string;
  upgradeBlocks: ApiProposalBlock[];
  summary: string;
}

export interface ApiOpeningWithTasksAndProposalResponse {
  opening: ApiOpeningRecord;
  div28Tasks: ApiGeneratedDiv28Task[];
  proposal: ApiProposalPayload;
}

const API_BASE =
  import.meta.env.VITE_OPENINGS_API_BASE ?? "http://localhost:3001/api";

export async function fetchOpening(id: string): Promise<ApiOpeningRecord> {
  const response = await fetch(`${API_BASE}/openings/${id}`);
  if (!response.ok) throw new Error("Failed to fetch opening");
  return response.json();
}

export async function createOpening(payload: {
  projectId: string;
  div8: ApiOpeningDiv8Core;
  div28Survey: ApiDiv28Survey;
}): Promise<ApiOpeningWithTasksAndProposalResponse> {
  const response = await fetch(`${API_BASE}/openings`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      projectId: payload.projectId,
      ...payload.div8,
      div28Survey: payload.div28Survey,
    }),
  });
  if (!response.ok) throw new Error("Failed to create opening");
  return response.json();
}

export async function updateOpening(payload: {
  id: string;
  projectId: string;
  div8?: Partial<ApiOpeningDiv8Core>;
  div28Survey?: ApiDiv28Survey;
}): Promise<ApiOpeningWithTasksAndProposalResponse> {
  const response = await fetch(`${API_BASE}/openings/${payload.id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      id: payload.id,
      projectId: payload.projectId,
      div8: payload.div8,
      div28Survey: payload.div28Survey,
    }),
  });
  if (!response.ok) throw new Error("Failed to update opening");
  return response.json();
}
