import {
  BrandConfig,
  Manufacturer,
  MasterKeySystem,
  MasterKeyNode,
  Keyway,
} from "./masterKeying";

export interface ManufacturerPreset {
  manufacturer: Manufacturer;
  label: string;
  description: string;
  defaultBrand: Partial<BrandConfig>;
  suggestedKeyways: Keyway[];
  seedNodes?: MasterKeyNode[];
}

export const manufacturerPresets: ManufacturerPreset[] = [
  {
    manufacturer: "Allegion",
    label: "Allegion / Schlage (Typical Healthcare)",
    description:
      "Common Schlage Everest or Primus keyways with Allegion-flavored branding.",
    defaultBrand: {
      orgName: "DoorSurvey Pro – Allegion Profile",
      primaryColor: "#f97316",
      secondaryColor: "#111827",
      footerText:
        "© 2025 DoorSurvey Pro – Allegion-Compatible Master Keying (Confidential)",
      watermarkText: "CONFIDENTIAL",
      hideBittingOnCustomerView: true,
    },
    suggestedKeyways: [
      {
        id: "kw_sch_ev_c123",
        name: "Schlage Everest C123",
        manufacturer: "Allegion",
      },
      {
        id: "kw_sch_primus",
        name: "Schlage Primus",
        manufacturer: "Allegion",
      },
    ],
    seedNodes: [
      {
        id: "seed_gmk1",
        systemId: "",
        code: "GMK1",
        fullName: "Grand Master 1",
        levelType: "GMK",
        manufacturer: "Allegion",
        keywayId: "kw_sch_ev_c123",
        bitting: undefined,
        parentId: undefined,
        childrenIds: [],
      },
      {
        id: "seed_mk_a",
        systemId: "",
        code: "MK-A",
        fullName: "Master A – Patient Areas",
        levelType: "MK",
        manufacturer: "Allegion",
        keywayId: "kw_sch_ev_c123",
        bitting: undefined,
        parentId: "seed_gmk1",
        childrenIds: [],
      },
    ],
  },
  {
    manufacturer: "ASSA ABLOY",
    label: "ASSA ABLOY / Medeco / Yale",
    description:
      "Preset for facilities with ASSA ABLOY brands; conservative blue profile.",
    defaultBrand: {
      orgName: "DoorSurvey Pro – ASSA ABLOY Profile",
      primaryColor: "#1d4ed8",
      secondaryColor: "#020617",
      footerText:
        "© 2025 DoorSurvey Pro – ASSA ABLOY-Compatible Master Key System",
      watermarkText: "SECURE",
      hideBittingOnCustomerView: true,
      hideKeywayOnCustomerView: true,
    },
    suggestedKeyways: [
      {
        id: "kw_medeco",
        name: "Medeco BiLevel / XT",
        manufacturer: "Medeco",
      },
      {
        id: "kw_yale_std",
        name: "Yale Standard",
        manufacturer: "ASSA ABLOY",
      },
    ],
  },
  {
    manufacturer: "dormakaba",
    label: "dormakaba",
    description:
      "Neutral preset for dormakaba-based systems, often used in hospitality.",
    defaultBrand: {
      primaryColor: "#0ea5e9",
      secondaryColor: "#0f172a",
      watermarkText: "CONFIDENTIAL",
      hideBittingOnCustomerView: true,
    },
    suggestedKeyways: [],
  },
  {
    manufacturer: "Other",
    label: "Generic / Mixed Manufacturer",
    description:
      "Use when multiple manufacturers or legacy systems are mixed.",
    defaultBrand: {
      primaryColor: "#4b5563",
      secondaryColor: "#020617",
      watermarkText: "CONFIDENTIAL",
    },
    suggestedKeyways: [],
  },
];

export function getManufacturerPreset(
  manufacturer: Manufacturer
): ManufacturerPreset | undefined {
  return manufacturerPresets.find((p) => p.manufacturer === manufacturer);
}

export function applyManufacturerPresetToSystem(
  system: MasterKeySystem,
  manufacturer: Manufacturer
): MasterKeySystem {
  const preset = getManufacturerPreset(manufacturer);
  if (!preset) return system;
  const now = new Date().toISOString();
  const brand: BrandConfig = {
    ...(system.brand ?? {
      orgName: "DoorSurvey Pro",
      primaryColor: "#F97316",
      secondaryColor: "#0F172A",
      termsAndConditions:
        "This master key system diagram is confidential. Distribution is strictly limited.",
    }),
    ...preset.defaultBrand,
  };
  const existingKeywayNames = new Set(
    system.keyways.map((k) => k.name.toLowerCase())
  );
  const newKeyways = [
    ...system.keyways,
    ...preset.suggestedKeyways.filter(
      (s) => !existingKeywayNames.has(s.name.toLowerCase())
    ),
  ];
  let newNodes = system.nodes;
  if (system.nodes.length === 0 && preset.seedNodes?.length) {
    newNodes = preset.seedNodes.map((n) => ({
      ...n,
      systemId: system.id,
    }));
  }
  return {
    ...system,
    manufacturer,
    brand,
    keyways: newKeyways,
    nodes: newNodes,
    updatedAt: now,
  };
}
