# customer-service - issue-resolved

**Subject:** Your Issue Has Been Resolved

Hi {{FirstName}},  
We’re happy to let you know that your issue regarding **{{Topic}}** has been resolved.

If there’s anything more we can do, feel free to reach out anytime.
