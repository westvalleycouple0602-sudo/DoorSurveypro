// src/server/routes/masterKeySystems.ts
import { Router, Request, Response } from "express";
import { eq } from "drizzle-orm";
import { db } from "../db/client"; // your configured Drizzle + Neon client
import { masterKeySystems } from "../db/schema/masterKeySystems";
import type { MasterKeySystem } from "../../masterKeying/masterKeying";

const router = Router();

router.get(
  "/api/master-key-systems/:id",
  async (req: Request, res: Response) => {
    try {
      const id = req.params.id;
      const rows = await db
        .select()
        .from(masterKeySystems)
        .where(eq(masterKeySystems.id, id));

      const row = rows[0];
      if (!row) {
        return res.status(404).json({ error: "Not found" });
      }

      return res.json(row);
    } catch (err) {
      console.error("GET /master-key-systems/:id error", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  }
);

router.get(
  "/api/facilities/:facilityId/master-key-systems",
  async (req: Request, res: Response) => {
    try {
      const facilityId = req.params.facilityId;
      const rows = await db
        .select()
        .from(masterKeySystems)
        .where(eq(masterKeySystems.facilityId, facilityId));

      return res.json(rows);
    } catch (err) {
      console.error("GET /facilities/:facilityId/master-key-systems error", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  }
);

router.post(
  "/api/facilities/:facilityId/master-key-systems",
  async (req: Request, res: Response) => {
    try {
      const facilityId = req.params.facilityId;
      const body = req.body as { system: MasterKeySystem };

      if (!body?.system) {
        return res.status(400).json({ error: "Missing system payload" });
      }

      const system = body.system;

      const toInsert = {
        id: system.id,
        facilityId,
        name: system.name,
        facilityName: system.facilityName,
        manufacturer: system.manufacturer ?? null,
        data: system,
      };

      const [inserted] = await db
        .insert(masterKeySystems)
        .values(toInsert)
        .returning();

      return res.status(201).json(inserted);
    } catch (err) {
      console.error(
        "POST /facilities/:facilityId/master-key-systems error",
        err
      );
      return res.status(500).json({ error: "Internal server error" });
    }
  }
);

router.put(
  "/api/master-key-systems/:id",
  async (req: Request, res: Response) => {
    try {
      const id = req.params.id;
      const body = req.body as { system: MasterKeySystem };

      if (!body?.system) {
        return res.status(400).json({ error: "Missing system payload" });
      }

      const system = body.system;

      const [updated] = await db
        .update(masterKeySystems)
        .set({
          name: system.name,
          facilityName: system.facilityName,
          manufacturer: system.manufacturer ?? null,
          data: system,
          updatedAt: new Date(),
        })
        .where(eq(masterKeySystems.id, id))
        .returning();

      if (!updated) {
        return res.status(404).json({ error: "Not found" });
      }

      return res.json(updated);
    } catch (err) {
      console.error("PUT /master-key-systems/:id error", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  }
);

export default router;
