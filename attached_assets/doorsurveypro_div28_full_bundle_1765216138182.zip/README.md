# DoorSurvey Pro – Div 8 + Div 28 Bundle (Backend + Frontend)

This bundle consolidates Div 28-related code into a clean structure ready to plug
into your DoorSurvey Pro stack.

- `backend/` – Express + Drizzle/Postgres + Div 28 scoring, tasks, and proposal text.
- `frontend/` – React + TS helpers for API calls, proposal rendering, export options,
  and alternate quote options.

Use your normal build tooling (Vite/tsc/esbuild) to handle production minification.
