// backend/src/server.ts
import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import pmRouter from "./pm/pmRouter";
import procurementRouter from "./procurement/procurementRouter";

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use("/api", pmRouter);
app.use("/api", procurementRouter);

app.get("/health", (_req, res) => {
  res.json({ ok: true });
});

const port = process.env.PORT || 3002;
app.listen(port, () => {
  console.log(`DoorSurvey Pro PM + Procurement API running on :${port}`);
});
