# DoorSurvey Pro – Master Keying Module

This folder contains the **full, unminified TypeScript/React source** for the Master Key System visualization and export module used in DoorSurvey Pro.

## Files

- `masterKeying.ts`  
  Core type definitions and models:
  - `MasterKeySystem`
  - `BrandConfig`
  - `KeyLevelType`
  - `MasterKeyNode`
  - `DoorOpeningRef`
  - `KeyDoorAssignment`
  - etc.

- `utils.ts`  
  Helper utilities:
  - `buildKeyTree(system)`
  - `createExportPayload(system, options)` – produces a redaction-aware payload for exports and matrix views.

- `MasterKeyDiagram.tsx`  
  React component that renders a **hierarchical diagram** of the key structure (GMK → MK → SMK → CHANGE).

- `MasterKeyPdfPreviewCard.tsx`  
  React component that shows a **PDF cover-style preview** for internal vs. customer views, including branding and confidentiality tags.

- `manufacturerPresets.ts`  
  Manufacturer presets and helpers:
  - Allegion / Schlage profile
  - ASSA ABLOY / Medeco / Yale profile
  - dormakaba profile
  - Generic profile  
  Includes:
  - `manufacturerPresets` array
  - `applyManufacturerPresetToSystem(system, manufacturer)`

- `KeyDoorMatrix.tsx`  
  React component that renders a **Key ↔ Door matrix**:
  - Search bar for keys/doors/locations
  - Clickable door tags
  - Respects internal vs. customer view redaction

- `DoorAccessPanel.tsx`  
  React component that answers **“Who can open this door?”**:
  - Shows all keys that operate a selected door
  - Shows hierarchy path (GMK → MK → CK) in internal view

- `MasterKeyWizard.tsx`  
  React “shell” that ties it all together:
  - Tabs for **Create**, **Brand**, **Preview / Export**
  - Branding editor with manufacturer presets
  - Preview panel with Diagram / Matrix toggle
  - Hooks for `onSaveInternal` and `onExport`

---

## How to Plug Into DoorSurvey Pro

### 1. Folder Structure

In your DoorSurvey Pro repo (Replit / GitHub / local), create:

```text
src/
  masterKeying/
    masterKeying.ts
    utils.ts
    MasterKeyDiagram.tsx
    MasterKeyPdfPreviewCard.tsx
    manufacturerPresets.ts
    KeyDoorMatrix.tsx
    DoorAccessPanel.tsx
    MasterKeyWizard.tsx
```

Then copy these files directly into `src/masterKeying/`.

### 2. Ensure TypeScript + React Setup

Your project should already be using:

- React 18+
- TypeScript
- A bundler like Vite / CRA / Next.js / Replit React template

If you are on Replit with a React + TS template, this will work out of the box.

### 3. Use the Wizard in a Page or Route

Example page component:

```tsx
// src/pages/MasterKeyingPage.tsx
import React from "react";
import { MasterKeyWizard } from "../masterKeying/MasterKeyWizard";
import type { MasterKeySystem } from "../masterKeying/masterKeying";
import { createExportPayload } from "../masterKeying/utils";

export const MasterKeyingPage: React.FC = () => {
  const handleSaveInternal = async (system: MasterKeySystem) => {
    // TODO: send to your backend API (e.g., POST /api/master-key-systems)
    console.log("Save system internally", system);
  };

  const handleExport = async (system: MasterKeySystem, view: "INTERNAL" | "CUSTOMER") => {
    const payload = createExportPayload(system, { view });
    // TODO: send payload to your PDF generator / export pipeline
    console.log("Export payload", view, payload);
  };

  return (
    <div className="p-4">
      <h1 className="text-lg font-semibold mb-3">Master Key System Designer</h1>
      <MasterKeyWizard
        initialSystem={undefined}
        onSaveInternal={handleSaveInternal}
        onExport={(payload, view) => handleExport(payload as MasterKeySystem, view)}
      />
    </div>
  );
};
```

> In DoorSurvey Pro, you can mount this under a route such as `/master-keying` or inside your facility detail view.

### 4. Wiring to Your Backend

In production, you will likely:

- Save `MasterKeySystem` objects to PostgreSQL (Neon) via your existing API
- Attach systems to:
  - Facilities
  - Projects
  - Door schedules

Suggested approach:

- Add a `master_key_systems` table keyed by `facility_id`
- Store the full `MasterKeySystem` as JSONB
- Optionally denormalize key/door mappings for reporting

### 5. Using the Minified Build (Optional)

If you want to **hide the implementation** and only ship minified logic:

- Use the **minified bundle** you already generated:
  - `master_keying_minified_real_bundle.zip`

You can:

- Keep this `/src/masterKeying/` folder in a private internal repo
- Only distribute the `/dist` or `.min.tsx` equivalents to public-facing code

---

## Replit Integration Notes

On Replit:

1. Upload this ZIP to your Replit project.
2. Extract it into `src/masterKeying/`.
3. Import `MasterKeyWizard` into a page as shown above.
4. Make sure your `tsconfig.json` includes `"jsx": "react-jsx"` or equivalent.
5. Run the Replit project; navigate to the route where you mounted the wizard.

---

If you need a **database schema example** (Drizzle / Prisma) or a **ready-to-use Express route** for saving/loading `MasterKeySystem`, I can generate those next.