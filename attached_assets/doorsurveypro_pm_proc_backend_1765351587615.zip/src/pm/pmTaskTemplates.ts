// backend/src/pm/pmTaskTemplates.ts
import type { PmPhase, PmTaskType, PmDiscipline, PmTask } from "./pmTypes";
import { v4 as uuidv4 } from "uuid";

export interface PmTaskTemplate {
  id: string;
  phase: PmPhase;
  discipline: PmDiscipline;
  type: PmTaskType;
  title: string;
  description: string;
  defaultRedFlag: boolean;
}

export const pmTaskTemplates: PmTaskTemplate[] = [
  {
    id: "precon-001",
    phase: "PRE_CONTRACT",
    discipline: "DIV8",
    type: "CHECKLIST",
    title: "Verify door and hardware schedule alignment",
    description:
      "Ensure the opening schedule, hardware sets, and specifications are aligned before pricing.",
    defaultRedFlag: false,
  },
  {
    id: "precon-002",
    phase: "PRE_CONTRACT",
    discipline: "DIV28",
    type: "CHECKLIST",
    title: "Identify Div 28 scope tied to Div 8 openings",
    description:
      "List access control, automatic operators, controlled egress, and surveillance required at door openings.",
    defaultRedFlag: false,
  },
  {
    id: "submittal-001",
    phase: "SUBMITTALS",
    discipline: "DIV8",
    type: "SUBMITTAL",
    title: "Prepare door and hardware submittal package",
    description:
      "Generate and submit door, frame, and hardware submittals including catalog cuts and schedule.",
    defaultRedFlag: false,
  },
  {
    id: "submittal-002",
    phase: "SUBMITTALS",
    discipline: "DIV28",
    type: "SUBMITTAL",
    title: "Prepare access control and security submittals",
    description:
      "Provide device layouts, riser diagrams, and sequence-of-operations for Div 28 systems tied to doors.",
    defaultRedFlag: false,
  },
  {
    id: "proc-001",
    phase: "PROCUREMENT",
    discipline: "DIV8",
    type: "PROCUREMENT",
    title: "Release door and hardware purchase orders",
    description:
      "Issue POs to door, frame, and hardware manufacturers based on approved submittals.",
    defaultRedFlag: false,
  },
  {
    id: "proc-002",
    phase: "PROCUREMENT",
    discipline: "DIV28",
    type: "PROCUREMENT",
    title: "Release access control and operator purchase orders",
    description:
      "Issue POs to access control, automatic operator, and security vendors for openings on the project.",
    defaultRedFlag: false,
  },
  {
    id: "install-001",
    phase: "INSTALLATION",
    discipline: "DIV8",
    type: "FIELD_ISSUE",
    title: "Document field conditions impacting openings",
    description:
      "Capture site deviations (wall thickness, clearances, blocking) that affect door and frame installation.",
    defaultRedFlag: true,
  },
  {
    id: "install-002",
    phase: "INSTALLATION",
    discipline: "DIV28",
    type: "FIELD_ISSUE",
    title: "Coordinate Div 28 cabling and device mounting",
    description:
      "Confirm power, data, and device mounting for access control, operators, and cameras at each opening.",
    defaultRedFlag: true,
  },
];

export function instantiateTasksForProject(params: {
  projectId: string;
  nowIso?: string;
}): PmTask[] {
  const { projectId, nowIso } = params;
  const now = nowIso ?? new Date().toISOString();

  return pmTaskTemplates.map((tmpl) => ({
    id: uuidv4(),
    projectId,
    openingId: null,
    phase: tmpl.phase,
    discipline: tmpl.discipline,
    type: tmpl.type,
    title: tmpl.title,
    description: tmpl.description,
    status: "NOT_STARTED",
    assigneeName: null,
    assigneeRole: null,
    dueDate: null,
    createdAt: now,
    updatedAt: now,
    redFlag: tmpl.defaultRedFlag,
  }));
}
