// backend/src/pm/pmRouter.ts
import express from "express";
import type { PmTask } from "./pmTypes";
import { instantiateTasksForProject } from "./pmTaskTemplates";

// In-memory store for PM tasks for demo / Replit prototype.
// In production you would back this with PostgreSQL/Drizzle.
const pmTasksByProject = new Map<string, PmTask[]>();

const router = express.Router();

router.post<{}, { tasks: PmTask[] }, { projectId: string }>(
  "/pm/bootstrap",
  (req, res) => {
    const { projectId } = req.body;
    if (!projectId) {
      return res.status(400).json({ error: "projectId is required" } as any);
    }

    const existing = pmTasksByProject.get(projectId);
    if (existing && existing.length) {
      return res.json({ tasks: existing });
    }

    const tasks = instantiateTasksForProject({ projectId });
    pmTasksByProject.set(projectId, tasks);
    res.status(201).json({ tasks });
  }
);

router.get<{}, { tasks: PmTask[] }>(
  "/pm/projects/:projectId/tasks",
  (req, res) => {
    const tasks = pmTasksByProject.get(req.params.projectId) ?? [];
    res.json({ tasks });
  }
);

router.patch<
  { taskId: string },
  { task?: PmTask; error?: string },
  Partial<PmTask>
>("/pm/projects/:projectId/tasks/:taskId", (req, res) => {
  const { projectId, taskId } = req.params;
  const tasks = pmTasksByProject.get(projectId);
  if (!tasks) {
    return res.status(404).json({ error: "Project not found" });
  }
  const idx = tasks.findIndex((t) => t.id === taskId);
  if (idx === -1) {
    return res.status(404).json({ error: "Task not found" });
  }
  const existing = tasks[idx];
  const updated: PmTask = {
    ...existing,
    ...req.body,
    updatedAt: new Date().toISOString(),
  };
  tasks[idx] = updated;
  pmTasksByProject.set(projectId, tasks);
  res.json({ task: updated });
});

export default router;
