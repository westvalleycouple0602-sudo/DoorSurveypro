import argparse, sys, time

# Placeholder synthetic test. Replace with Playwright flow if you have a UI URL.

def run():
    t0 = time.time()
    # Step 1: open app (stub)
    time.sleep(0.5)
    # Step 2: login (stub)
    time.sleep(0.5)
    # Step 3: new survey -> scan -> save (stub)
    time.sleep(0.5)
    dt = time.time() - t0
    print({"synthetic_total_sec": round(dt,2)})
    return 0

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--headless", action="store_true")
    args = parser.parse_args()
    sys.exit(run())
