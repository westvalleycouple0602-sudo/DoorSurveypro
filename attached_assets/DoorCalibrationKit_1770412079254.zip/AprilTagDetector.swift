import ARKit
import Vision

enum AprilTagDetector {
    static func detect() {}
}
