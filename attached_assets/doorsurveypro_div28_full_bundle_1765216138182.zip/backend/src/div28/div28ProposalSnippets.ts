// backend/src/div28/div28ProposalSnippets.ts
import { Div28Feature, Div28OpportunitySummary } from "./div28Types";

export interface ProposalTextBlock {
  id: string;
  title: string;
  body: string;
  appliesToFeatures: Div28Feature[];
}

export interface OpeningProposalPackage {
  openingId: string;
  summary: string;
  baseOptionText: string;
  upgradeOptions: ProposalTextBlock[];
}

const baseOptionTemplate = (openingLabel: string) => `
Base hardware package for ${openingLabel} includes code-compliant door, frame,
and mechanical hardware. This option provides reliable operation and life-safety
performance without electronic access or monitoring.
`.trim();

function featureBlock(
  feature: Div28Feature,
  openingLabel: string
): ProposalTextBlock {
  switch (feature) {
    case "ACCESS_CONTROL":
      return {
        id: "access-control-upgrade",
        title: "Access Control Upgrade",
        appliesToFeatures: ["ACCESS_CONTROL"],
        body: `
Add electronic access control to ${openingLabel} to provide credential-based entry,
audit trail of usage, and the ability to update access rights without rekeying.
This package typically includes electrified locking hardware, reader devices,
door position monitoring, and integration to the customer's access control system.
`.trim(),
      };
    case "DOOR_AUTOMATION":
      return {
        id: "door-automation-upgrade",
        title: "Automatic Operator Upgrade",
        appliesToFeatures: ["DOOR_AUTOMATION"],
        body: `
Provide an automatic door operator at ${openingLabel} to support accessibility,
high-traffic usage, and touchless operation where desired. This package is designed
to coordinate with required safety sensors, actuators, and access control devices.
`.trim(),
      };
    case "CONTROLLED_EGRESS":
      return {
        id: "controlled-egress-upgrade",
        title: "Controlled Egress Package",
        appliesToFeatures: ["CONTROLLED_EGRESS"],
        body: `
Implement a controlled egress solution at ${openingLabel}, typically used in healthcare
and secured units where patient or resident movement must be supervised. All configurations
will be designed and installed in accordance with applicable life-safety codes and with
the approval of the Authority Having Jurisdiction (AHJ).
`.trim(),
      };
    case "DELAYED_EGRESS":
      return {
        id: "delayed-egress-upgrade",
        title: "Delayed Egress Package",
        appliesToFeatures: ["DELAYED_EGRESS"],
        body: `
Provide delayed egress hardware at ${openingLabel} to help reduce elopement or theft while
maintaining a code-compliant means of egress. This includes local audible alarm, timed
release, and integration to fire alarm or emergency override circuits as required.
`.trim(),
      };
    case "SURVEILLANCE":
      return {
        id: "surveillance-upgrade",
        title: "Video Surveillance at Opening",
        appliesToFeatures: ["SURVEILLANCE"],
        body: `
Add a dedicated camera coverage point for ${openingLabel} to improve visibility, incident
review, and verification of alarms. Camera placement and field-of-view will be coordinated
with the overall video management system design.
`.trim(),
      };
    case "INTRUSION_DETECTION":
      return {
        id: "intrusion-upgrade",
        title: "Intrusion Detection at Opening",
        appliesToFeatures: ["INTRUSION_DETECTION"],
        body: `
Integrate ${openingLabel} with the intrusion detection system using door contacts and,
where applicable, motion or glassbreak detection. This provides alarm reporting for
forced entry, propped doors, or after-hours access attempts.
`.trim(),
      };
    case "LOCKDOWN_CONTROL":
      return {
        id: "lockdown-upgrade",
        title: "Lockdown-Ready Opening",
        appliesToFeatures: ["LOCKDOWN_CONTROL"],
        body: `
Configure ${openingLabel} to participate in local or building-wide lockdown scenarios.
This may include electrified hardware compatible with group commands, status monitoring,
and integration with existing lockdown or mass-notification systems, while maintaining
required egress conditions.
`.trim(),
      };
    case "GUN_DETECTION_READY":
      return {
        id: "gun-detection-ready-upgrade",
        title: "Threat Detection-Ready Entry",
        appliesToFeatures: ["GUN_DETECTION_READY"],
        body: `
Design ${openingLabel} as an analytics-ready entry point for use with compatible
video-based or sensor-based threat detection platforms selected by the customer.
This includes appropriate camera/sensor mounting, coverage, and power/data pathway
considerations. Selection and configuration of specific detection analytics will be
performed in coordination with the customer's security provider.
`.trim(),
      };
    default:
      return {
        id: "generic-upgrade",
        title: "Electronic Safety & Security Upgrade",
        appliesToFeatures: [feature],
        body: `
Electronic safety and security enhancements are recommended at this opening.
Details to be coordinated with the customer's security and IT stakeholders.
`.trim(),
      };
  }
}

export function buildOpeningProposalPackage(
  openingId: string,
  openingLabel: string,
  opportunity: Div28OpportunitySummary
): OpeningProposalPackage {
  const baseText = baseOptionTemplate(openingLabel);
  const uniqueFeatures = Array.from(new Set(opportunity.recommendedFeatures));
  const blocks = uniqueFeatures.map((feature) =>
    featureBlock(feature, openingLabel)
  );

  const summaryLines: string[] = [];
  summaryLines.push(opportunity.narrativeSummary);
  if (opportunity.warnings.length) {
    summaryLines.push("");
    summaryLines.push("Important notes and coordination items:");
    for (const warning of opportunity.warnings) {
      summaryLines.push(`- ${warning}`);
    }
  }

  return {
    openingId,
    summary: summaryLines.join("\n"),
    baseOptionText: baseText,
    upgradeOptions: blocks,
  };
}
