// frontend/src/features/procurement/ProcurementChecklistPanel.tsx
import React from "react";

export interface ProcurementRedFlagLine {
  id: string;
  manufacturer: string;
  openingLabel?: string | null;
  hardwareSetId?: string | null;
  description: string;
  redFlags: string[];
}

export interface ProcurementChecklistPanelProps {
  lines: ProcurementRedFlagLine[];
}

export const ProcurementChecklistPanel: React.FC<ProcurementChecklistPanelProps> = ({
  lines,
}) => {
  if (!lines.length) {
    return (
      <div className="border rounded-md p-3 text-xs text-slate-500 bg-slate-50">
        No procurement lines or red flags detected yet.
      </div>
    );
  }

  return (
    <div className="border rounded-md p-3 bg-white text-xs space-y-3">
      <header className="border-b pb-2 mb-2">
        <h2 className="text-sm font-semibold">Procurement Red-Flag Review</h2>
        <p className="text-[11px] text-slate-500">
          Quickly scan items that need clarification before releasing orders
          to manufacturers.
        </p>
      </header>

      <div className="space-y-2 max-h-[420px] overflow-auto">
        {lines.map((line) => (
          <article
            key={line.id}
            className="border rounded-md p-2 bg-slate-50 space-y-1"
          >
            <div className="flex justify-between gap-2 text-[11px]">
              <span className="font-semibold">{line.description}</span>
              <span className="text-[10px] text-slate-600">
                {line.manufacturer}
              </span>
            </div>
            {(line.openingLabel || line.hardwareSetId) && (
              <div className="text-[10px] text-slate-500">
                {line.openingLabel && <span>{line.openingLabel}</span>}
                {line.openingLabel && line.hardwareSetId && <span> · </span>}
                {line.hardwareSetId && <span>Set {line.hardwareSetId}</span>}
              </div>
            )}
            {line.redFlags.length > 0 && (
              <ul className="list-disc ml-4 text-[10px] text-rose-700 space-y-0.5">
                {line.redFlags.map((flag, idx) => (
                  <li key={idx}>{flag}</li>
                ))}
              </ul>
            )}
          </article>
        ))}
      </div>
    </div>
  );
};
