export type Manufacturer =
  | "Allegion"
  | "ASSA ABLOY"
  | "dormakaba"
  | "Medeco"
  | "Best"
  | "Other";

export type KeyLevelType =
  | "GMK"
  | "MK"
  | "SMK"
  | "CHANGE"
  | "CONSTRUCTION"
  | "VENDOR"
  | "SPECIAL";

export interface BrandConfig {
  orgName: string;
  primaryColor: string;
  secondaryColor: string;
  logoUrl?: string;
  watermarkText?: string;
  footerText?: string;
  termsAndConditions: string;
  hideManufacturerNamesOnCustomerView?: boolean;
  hideBittingOnCustomerView?: boolean;
  hideKeywayOnCustomerView?: boolean;
}

export interface Keyway {
  id: string;
  name: string;
  manufacturer: Manufacturer;
  notes?: string;
}

export interface MasterKeyNode {
  id: string;
  systemId: string;
  code: string;
  fullName: string;
  levelType: KeyLevelType;
  keywayId?: string;
  manufacturer?: Manufacturer;
  bitting?: string;
  parentId?: string;
  childrenIds: string[];
  notes?: string;
}

export interface DoorOpeningRef {
  id: string;
  label: string;
  locationPath?: string;
}

export interface KeyDoorAssignment {
  id: string;
  keyNodeId: string;
  doorId: string;
}

export interface MasterKeySystem {
  id: string;
  name: string;
  facilityName: string;
  manufacturer?: Manufacturer;
  keyways: Keyway[];
  nodes: MasterKeyNode[];
  doorOpenings: DoorOpeningRef[];
  assignments: KeyDoorAssignment[];
  brand?: BrandConfig;
  createdAt: string;
  updatedAt: string;
}

export interface ImportFileResult {
  system: MasterKeySystem;
  warnings: string[];
}

export interface ExportOptions {
  view: "INTERNAL" | "CUSTOMER";
  includeBitting?: boolean;
  includeKeyway?: boolean;
  includeManufacturer?: boolean;
  includeDoorLocationPaths?: boolean;
}
