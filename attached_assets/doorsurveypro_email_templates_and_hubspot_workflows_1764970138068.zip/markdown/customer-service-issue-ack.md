# customer-service - issue-ack

**Subject:** We Received Your Request — We’re On It

Hi {{FirstName}},  
Thanks for bringing this to our attention.  
Our team is reviewing the issue and will follow up within {{Timeframe}} with next steps.

We appreciate your patience.
