# proposal - upgrade-options

**Subject:** Optional Upgrades for {{ProjectName}}

Hi {{FirstName}},  
Based on your project details, here are optional upgrades that may benefit you:

- **Electronic access control (Div 28)**  
- **Grade 1 hardware upgrades**  
- **Security or anti-ligature options**  
- **Energy-efficient or acoustical door assemblies**  

Let me know if you’d like pricing.
