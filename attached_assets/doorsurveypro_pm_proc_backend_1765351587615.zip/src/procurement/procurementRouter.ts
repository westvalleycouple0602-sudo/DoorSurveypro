// backend/src/procurement/procurementRouter.ts
import express from "express";
import type { ProcurementPackage } from "./procurementTypes";
import { groupLinesIntoPackages } from "./procurementEngine";

const router = express.Router();

// In-memory store for demo / proto
const packagesByProject = new Map<string, ProcurementPackage[]>();

router.post("/procurement/build", (req, res) => {
  const { lines } = req.body as { lines: any[] };
  if (!Array.isArray(lines) || !lines.length) {
    return res.status(400).json({ error: "lines array is required" });
  }

  const pkgs = groupLinesIntoPackages(lines as any);
  for (const pkg of pkgs) {
    const existing = packagesByProject.get(pkg.projectId) ?? [];
    existing.push(pkg);
    packagesByProject.set(pkg.projectId, existing);
  }

  res.status(201).json({ packages: pkgs });
});

router.get("/procurement/projects/:projectId/packages", (req, res) => {
  const list = packagesByProject.get(req.params.projectId) ?? [];
  res.json({ packages: list });
});

export default router;
