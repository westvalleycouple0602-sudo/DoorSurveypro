import React, { useMemo, useState } from "react";
import type { MasterKeySystem } from "./masterKeying";
import { createExportPayload } from "./utils";

interface KeyDoorMatrixProps {
  system: MasterKeySystem;
  view: "INTERNAL" | "CUSTOMER";
  onDoorClick?: (doorId: string) => void;
}

export const KeyDoorMatrix: React.FC<KeyDoorMatrixProps> = ({
  system,
  view,
  onDoorClick,
}) => {
  const exportData = useMemo(
    () => createExportPayload(system, { view }),
    [system, view]
  );
  const { nodes, doors, assignments } = exportData;
  const nodeById = new Map(nodes.map((n) => [n.id, n]));
  const doorById = new Map(doors.map((d) => [d.id, d]));

  const baseRows = useMemo(
    () =>
      assignments
        .map((a) => {
          const node = nodeById.get(a.keyNodeId);
          const door = doorById.get(a.doorId);
          if (!node || !door) return null;
          return {
            keyCode: node.code,
            levelType: node.levelType,
            keyName: node.fullName ?? node.code,
            doorId: door.id,
            doorLabel: door.label,
            doorLocation: door.locationPath ?? "",
          };
        })
        .filter((r): r is NonNullable<typeof r> => !!r)
        .sort((a, b) => {
          if (a.keyCode === b.keyCode) {
            return a.doorLabel.localeCompare(b.doorLabel);
          }
          return a.keyCode.localeCompare(b.keyCode);
        }),
    [assignments, nodeById, doorById]
  );

  const [search, setSearch] = useState("");

  const filteredRows = useMemo(() => {
    if (!search.trim()) return baseRows;
    const q = search.trim().toLowerCase();
    return baseRows.filter((r) => {
      return (
        r.keyCode.toLowerCase().includes(q) ||
        r.keyName.toLowerCase().includes(q) ||
        r.levelType.toLowerCase().includes(q) ||
        r.doorLabel.toLowerCase().includes(q) ||
        r.doorLocation.toLowerCase().includes(q)
      );
    });
  }, [baseRows, search]);

  if (baseRows.length === 0) {
    return (
      <div className="text-xs text-slate-500 border rounded-md p-3 bg-slate-50">
        No key/door assignments yet. Import a master key schedule or assign keys to
        doors in your editor.
      </div>
    );
  }

  return (
    <div className="border rounded-md overflow-hidden bg-white text-xs">
      <div className="px-3 py-2 border-b bg-slate-50 flex flex-col gap-1 md:flex-row md:items-center md:justify-between">
        <div>
          <span className="font-semibold">Key / Door Assignment Matrix</span>
          <span className="ml-2 text-[10px] text-slate-500">
            {view === "INTERNAL"
              ? "Internal view – may show full structure"
              : "Customer-safe view – sensitive details redacted"}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <input
            type="text"
            placeholder="Search key or door…"
            className="border rounded px-2 py-[3px] text-[11px] w-44 md:w-56"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="max-h-80 overflow-auto">
        <table className="w-full border-collapse text-[11px]">
          <thead>
            <tr className="bg-slate-100">
              <th className="border px-2 py-1 text-left">Key Code</th>
              <th className="border px-2 py-1 text-left">Level</th>
              <th className="border px-2 py-1 text-left">Key Name</th>
              <th className="border px-2 py-1 text-left">Door Tag</th>
              <th className="border px-2 py-1 text-left">Location</th>
            </tr>
          </thead>
          <tbody>
            {filteredRows.map((r, idx) => (
              <tr
                key={`${r.keyCode}-${r.doorLabel}-${idx}`}
                className={idx % 2 === 0 ? "bg-white" : "bg-slate-50/50"}
              >
                <td className="border px-2 py-1 whitespace-nowrap">
                  {r.keyCode}
                </td>
                <td className="border px-2 py-1 whitespace-nowrap">
                  {r.levelType}
                </td>
                <td className="border px-2 py-1">
                  {r.keyName}
                </td>
                <td className="border px-2 py-1 whitespace-nowrap">
                  {onDoorClick ? (
                    <button
                      type="button"
                      className="underline text-blue-600 hover:text-blue-800"
                      onClick={() => onDoorClick(r.doorId)}
                    >
                      {r.doorLabel}
                    </button>
                  ) : (
                    r.doorLabel
                  )}
                </td>
                <td className="border px-2 py-1">
                  {r.doorLocation || "-"}
                </td>
              </tr>
            ))}
            {filteredRows.length === 0 && (
              <tr>
                <td
                  colSpan={5}
                  className="border px-2 py-3 text-center text-[11px] text-slate-500"
                >
                  No results match “{search.trim()}”.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="px-3 py-2 border-t bg-slate-50 text-[10px] text-slate-500 flex justify-between">
        <span>
          Showing {filteredRows.length} of {baseRows.length} assignments
        </span>
        <span>
          Keys: {nodes.length} • Doors: {doors.length}
        </span>
      </div>
    </div>
  );
};
