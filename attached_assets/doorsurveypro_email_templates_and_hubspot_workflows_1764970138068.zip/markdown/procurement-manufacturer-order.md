# procurement - manufacturer-order

**Subject:** Order Submission – {{ProjectName}} ({{Manufacturer}})

Hello,  
Attached is the order form for **{{ProjectName}}**, including all line items, finishes, quantities, and required on-site dates.

Please confirm acknowledgment and estimated lead times.

Thank you,  
{{YourName}}
