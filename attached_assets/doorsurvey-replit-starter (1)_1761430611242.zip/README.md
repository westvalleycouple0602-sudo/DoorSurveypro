# Self-Healing + Telemetry Starter (Replit)

## Quick Start
1. Add packages: `pip install -r requirements.txt`. On Replit, enable Nix; `replit.nix` is provided.
2. Set Replit Secrets from `.env.example` (Sentry, PostHog, Jira optional).
3. Build Playwright once: `playwright install --with-deps` (Shell).
4. Run the API: `uvicorn app.main:app --host 0.0.0.0 --port $PORT` (or press Run).
5. Open your web client and call `initRUM(userId)`; verify `/rum` events arrive in PostHog.

## Health
- `GET /_health/alive` — liveness
- `GET /_health/ready` — readiness with dependency checks

## Processes (Procfile)
- `api` — FastAPI server
- `worker` — background RQ worker (wire up tasks if needed)
- `repair` — self-heal loop
- `synthetic` — synthetic journey (replace with Playwright flow)

## Extend
- Implement real DB/Redis pings in `health.py`.
- Replace synthetic stub with real Playwright script.
- Add metrics store (Prometheus) and wire error_rate/queue_depth in `repair_worker.py`.
- Add feature gates where risky logic lives; read via `flags.get_flag()`.

## Privacy
- Do not log PII. Configure masking in PostHog/Sentry. Set data retention windows.
