# prospecting - intro

**Subject:** Modernizing Door Surveys and Hardware Procurement

Hi {{FirstName}},  
We help contractors, architects, and facility managers eliminate errors in door and hardware projects using:

- LiDAR scanning  
- Code validation  
- Automated hardware sets  
- Project management workflows  
- One-click procurement packages  

Would you like a quick walkthrough?
