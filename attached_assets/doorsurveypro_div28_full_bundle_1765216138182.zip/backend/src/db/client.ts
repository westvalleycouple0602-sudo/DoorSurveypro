// backend/src/db/client.ts
import postgres from "postgres";
import { drizzle } from "drizzle-orm/postgres-js";

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  console.warn(
    "[Div28 DB] DATABASE_URL is not set. Database calls will fail until configured."
  );
}

const queryClient = connectionString
  ? postgres(connectionString, { max: 1 })
  : undefined as any;

export const db = queryClient ? drizzle(queryClient) : null;
export type DB = typeof db;
