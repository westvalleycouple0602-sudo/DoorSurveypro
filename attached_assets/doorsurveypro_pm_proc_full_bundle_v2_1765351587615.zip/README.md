# DoorSurvey Pro – PM + Procurement Expansion v2

This package contains:

- Backend: Express API for PM tasks (with Div 28 feature tags & filters)
  and procurement packet building
- Frontend: React components for PM board and procurement red-flag review

New in v2:

- Feature-tagged PM tasks (ACCESS_CONTROL, LOCKDOWN, etc.)
- Filter endpoints for Div 28 only and by feature tag
