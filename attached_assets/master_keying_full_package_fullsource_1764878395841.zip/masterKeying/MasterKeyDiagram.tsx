import React from "react";
import type { MasterKeySystem } from "./masterKeying";
import { buildKeyTree, KeyTreeNode } from "./utils";

interface MasterKeyDiagramProps {
  system: MasterKeySystem;
  width?: number;
  nodeWidth?: number;
  nodeHeight?: number;
  verticalSpacing?: number;
  horizontalSpacing?: number;
}

interface PositionedNode {
  node: KeyTreeNode;
  x: number;
  y: number;
}

export const MasterKeyDiagram: React.FC<MasterKeyDiagramProps> = ({
  system,
  width = 1200,
  nodeWidth = 160,
  nodeHeight = 40,
  verticalSpacing = 40,
  horizontalSpacing = 80,
}) => {
  const roots = buildKeyTree(system);
  const positionedNodes: PositionedNode[] = [];
  let currentY = 0;

  function layout(node: KeyTreeNode, depth: number): number {
    const childYs: number[] = [];
    for (const child of node.children) {
      const childY = layout(child, depth + 1);
      childYs.push(childY);
    }
    let y: number;
    if (childYs.length === 0) {
      y = currentY;
      currentY += nodeHeight + verticalSpacing;
    } else {
      y = (Math.min(...childYs) + Math.max(...childYs)) / 2 - nodeHeight / 2;
    }
    positionedNodes.push({
      node,
      x: depth * (nodeWidth + horizontalSpacing),
      y,
    });
    return y + nodeHeight / 2;
  }

  roots.forEach((root) => layout(root, 0));

  const height =
    (positionedNodes.reduce(
      (max, p) => Math.max(max, p.y + nodeHeight),
      0
    ) || 400) + verticalSpacing;

  const primaryColor = system.brand?.primaryColor ?? "#2563EB";
  const secondaryColor = system.brand?.secondaryColor ?? "#0F172A";

  return (
    <div className="w-full overflow-auto border rounded-md bg-white">
      <svg width={width} height={height}>
        {system.brand?.watermarkText && (
          <text
            x={width / 2}
            y={height / 2}
            textAnchor="middle"
            opacity={0.08}
            fontSize={64}
            fill={secondaryColor}
          >
            {system.brand.watermarkText}
          </text>
        )}
        {positionedNodes.map((p) => {
          const parentId = p.node.parentId;
          if (!parentId) return null;
          const parent = positionedNodes.find((n) => n.node.id === parentId);
          if (!parent) return null;
          const x1 = parent.x + nodeWidth;
          const y1 = parent.y + nodeHeight / 2;
          const x2 = p.x;
          const y2 = p.y + nodeHeight / 2;
          return (
            <line
              key={`edge-${parent.node.id}-${p.node.id}`}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke="#CBD5F5"
              strokeWidth={2}
            />
          );
        })}
        {positionedNodes.map((p) => {
          const node = p.node;
          return (
            <g key={node.id}>
              <rect
                x={p.x}
                y={p.y}
                width={nodeWidth}
                height={nodeHeight}
                rx={6}
                ry={6}
                fill={primaryColor}
                stroke={secondaryColor}
                strokeWidth={1}
              />
              <text
                x={p.x + 8}
                y={p.y + 16}
                fontSize={11}
                fill="white"
              >
                {node.code} ({node.levelType})
              </text>
              <text
                x={p.x + 8}
                y={p.y + 30}
                fontSize={9}
                fill="#DBEAFE"
              >
                {node.fullName}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
};
