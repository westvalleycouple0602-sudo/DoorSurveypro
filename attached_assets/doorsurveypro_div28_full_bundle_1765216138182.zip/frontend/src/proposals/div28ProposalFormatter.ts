// frontend/src/proposals/div28ProposalFormatter.ts
import type {
  ProposalPayload,
  RenderedProposalText,
} from "./div28ProposalTypes";

function escapeHtml(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

export function proposalToPlainText(
  openingLabel: string,
  proposal: ProposalPayload
): string {
  const lines: string[] = [];

  lines.push(`PROPOSAL – ${openingLabel}`);
  lines.push("");

  lines.push("Summary");
  lines.push("-------");
  lines.push(proposal.summary);
  lines.push("");

  lines.push("Base Option");
  lines.push("-----------");
  lines.push(proposal.baseOptionText);
  lines.push("");

  if (proposal.upgradeBlocks.length) {
    lines.push("Recommended Electronic & Security Upgrades");
    lines.push("-----------------------------------------");
    for (const block of proposal.upgradeBlocks) {
      lines.push("");
      lines.push(block.title.toUpperCase());
      lines.push("".padEnd(block.title.length, "-"));
      lines.push(block.body);
    }
  }

  return lines.join("\n");
}

export function proposalToMarkdown(
  openingLabel: string,
  proposal: ProposalPayload
): string {
  const lines: string[] = [];

  lines.push(`# Proposal – ${openingLabel}`);
  lines.push("");
  lines.push("## Summary");
  lines.push("");
  lines.push(proposal.summary);
  lines.push("");
  lines.push("## Base Option");
  lines.push("");
  lines.push(proposal.baseOptionText);
  lines.push("");

  if (proposal.upgradeBlocks.length) {
    lines.push("## Recommended Electronic & Security Upgrades");
    lines.push("");
    for (const block of proposal.upgradeBlocks) {
      lines.push(`### ${block.title}`);
      lines.push("");
      lines.push(block.body);
      lines.push("");
    }
  }

  return lines.join("\n");
}

export function proposalToHtml(
  openingLabel: string,
  proposal: ProposalPayload
): string {
  const esc = escapeHtml;
  const parts: string[] = [];

  parts.push(`<div class="dspro-proposal">`);
  parts.push(`<h1>Proposal – ${esc(openingLabel)}</h1>`);

  parts.push(`<section class="dspro-proposal-summary">`);
  parts.push(`<h2>Summary</h2>`);
  parts.push(
    `<p>${esc(proposal.summary).replace(/\n/g, "<br/>")}</p>`
  );
  parts.push(`</section>`);

  parts.push(`<section class="dspro-proposal-base-option">`);
  parts.push(`<h2>Base Option</h2>`);
  parts.push(
    `<p>${esc(proposal.baseOptionText).replace(/\n/g, "<br/>")}</p>`
  );
  parts.push(`</section>`);

  if (proposal.upgradeBlocks.length) {
    parts.push(`<section class="dspro-proposal-upgrades">`);
    parts.push(`<h2>Recommended Electronic &amp; Security Upgrades</h2>`);

    for (const block of proposal.upgradeBlocks) {
      parts.push(`<article class="dspro-proposal-upgrade">`);
      parts.push(`<h3>${esc(block.title)}</h3>`);
      parts.push(
        `<p>${esc(block.body).replace(/\n/g, "<br/>")}</p>`
      );
      parts.push(`</article>`);
    }

    parts.push(`</section>`);
  }

  parts.push(`</div>`);

  return parts.join("");
}

export function renderProposalAllFormats(
  openingLabel: string,
  proposal: ProposalPayload
): RenderedProposalText {
  return {
    plainText: proposalToPlainText(openingLabel, proposal),
    markdown: proposalToMarkdown(openingLabel, proposal),
    html: proposalToHtml(openingLabel, proposal),
  };
}
