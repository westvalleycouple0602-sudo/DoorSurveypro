# Backend – PM & Procurement Modules (v2, with Div 28 feature tags)

This backend bundle provides:

- PM task templates with rich Div 28 coverage and feature tags
- Filterable PM API (Div 28 only, or by feature tag)
- Procurement grouping engine by manufacturer (Div 8 + Div 28)
- Express server exposing `/api/pm/*` and `/api/procurement/*` routes

New in v2:

- `PmFeatureTag` type to tag tasks (ACCESS_CONTROL, LOCKDOWN, etc.)
- `GET /api/pm/projects/:projectId/tasks/div28-only`
- `GET /api/pm/projects/:projectId/tasks/by-feature?tag=ACCESS_CONTROL`

## Quick start

```bash
cd backend
npm install express cors body-parser uuid
# plus TypeScript tooling, then:
ts-node src/server.ts
```
