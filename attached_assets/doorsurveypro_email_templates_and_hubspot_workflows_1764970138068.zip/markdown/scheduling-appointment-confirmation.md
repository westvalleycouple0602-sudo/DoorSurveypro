# scheduling - appointment-confirmation

**Subject:** Your Survey Appointment Is Confirmed

Hi {{FirstName}},  
Your appointment is confirmed for:

📅 **{{Date}}**  
⏰ **{{Time}}**  
📍 **{{Location}}**

You’ll receive a reminder 24 hours before.

Looking forward to meeting you onsite.
