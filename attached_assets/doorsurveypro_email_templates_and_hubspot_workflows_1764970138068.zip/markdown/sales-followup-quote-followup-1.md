# sales-followup - quote-followup-1

**Subject:** Following Up on Your DoorSurvey Pro Proposal

Hi {{FirstName}},  
I wanted to follow up on the proposal we sent you on {{DateSent}}.  
Please let me know if you have any questions or would like to review options.

I’m here to help!
