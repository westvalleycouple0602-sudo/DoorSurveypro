# proposal - proposal-delivery

**Subject:** Your Proposal from DoorSurvey Pro

Hi {{FirstName}},  
Attached is your customized proposal for {{ProjectName}}.  
Inside you’ll find:

- Measured opening data  
- Recommended hardware sets  
- Code compliance notes  
- Pricing with options  
- Lead times & procurement details  

If you’d like revisions, add-ons, or an alternative solution, just reply.
