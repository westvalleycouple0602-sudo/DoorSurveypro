// frontend/src/proposals/div28ProposalTypes.ts
import type {
  ApiProposalPayload,
  ApiProposalBlock,
} from "../api/openingsClientProposals";

export type ProposalPayload = ApiProposalPayload;
export type ProposalBlock = ApiProposalBlock;

export interface RenderedProposalText {
  plainText: string;
  markdown: string;
  html: string;
}
