// frontend/src/quotes/QuoteExportOptionsForm.tsx
import React from "react";
import type { QuoteExportOptions, PricingMode } from "./quoteExportConfig";

export interface QuoteExportOptionsFormProps {
  value: QuoteExportOptions;
  onChange: (next: QuoteExportOptions) => void;
}

const pricingModes: { value: PricingMode; label: string; description: string }[] = [
  {
    value: "LINE_ITEM",
    label: "Line Item",
    description: "Show detailed line items for each component and opening.",
  },
  {
    value: "OPENING_PACKAGE",
    label: "Opening Package",
    description: "Show one lump sum per opening (door package).",
  },
  {
    value: "PROJECT_SUMMARY",
    label: "Project Summary",
    description: "One rolled-up price for entire project, minimal breakdown.",
  },
];

const div28Modes = [
  {
    value: "NONE" as const,
    label: "Hide Div 28",
    description: "Only show Division 8 (doors, frames, hardware).",
  },
  {
    value: "INLINE" as const,
    label: "Inline per Opening",
    description: "Show Div 28 narrative under each applicable opening.",
  },
  {
    value: "APPENDIX" as const,
    label: "Appendix",
    description: "Keep Div 28 narrative in a separate appendix section.",
  },
];

export const QuoteExportOptionsForm: React.FC<QuoteExportOptionsFormProps> = ({
  value,
  onChange,
}) => {
  const update = <K extends keyof QuoteExportOptions>(key: K, v: QuoteExportOptions[K]) => {
    onChange({ ...value, [key]: v });
  };

  const updateDiv28 = <K extends keyof QuoteExportOptions["div28"]>(
    key: K,
    v: QuoteExportOptions["div28"][K]
  ) => {
    onChange({
      ...value,
      div28: {
        ...value.div28,
        [key]: v,
      },
    });
  };

  return (
    <div className="space-y-4 text-sm">
      <div className="space-y-2">
        <h2 className="font-semibold text-base">Pricing Layout</h2>
        <div className="grid gap-2 sm:grid-cols-3">
          {pricingModes.map((mode) => (
            <button
              key={mode.value}
              type="button"
              onClick={() => update("pricingMode", mode.value)}
              className={[
                "border rounded-md p-2 text-left text-xs",
                value.pricingMode === mode.value
                  ? "border-sky-500 bg-sky-50"
                  : "border-slate-200 bg-white",
              ].join(" ")}
            >
              <div className="font-semibold text-[13px]">{mode.label}</div>
              <div className="text-[11px] text-slate-600">
                {mode.description}
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <h3 className="font-semibold text-[13px]">Financial Details</h3>
          <label className="flex items-center gap-2 text-xs">
            <input
              type="checkbox"
              checked={value.showTaxes}
              onChange={(event) => update("showTaxes", event.target.checked)}
            />
            <span>Show tax lines</span>
          </label>
          <label className="flex items-center gap-2 text-xs">
            <input
              type="checkbox"
              checked={value.showLaborBreakout}
              onChange={(event) => update("showLaborBreakout", event.target.checked)}
            />
            <span>Show labor vs material breakout</span>
          </label>
          <label className="flex items-center gap-2 text-xs">
            <input
              type="checkbox"
              checked={value.showOpeningBreakdown}
              onChange={(event) => update("showOpeningBreakdown", event.target.checked)}
            />
            <span>Show per-opening breakdown</span>
          </label>
        </div>

        <div className="space-y-2">
          <h3 className="font-semibold text-[13px]">Div 28 / Security Content</h3>
          <div className="space-y-1">
            {div28Modes.map((mode) => (
              <label
                key={mode.value}
                className="flex items-start gap-2 text-xs border rounded-md p-2"
              >
                <input
                  type="radio"
                  name="div28-mode"
                  value={mode.value}
                  checked={value.div28.mode === mode.value}
                  onChange={() => updateDiv28("mode", mode.value)}
                  className="mt-[2px]"
                />
                <span>
                  <div className="font-semibold text-[12px]">{mode.label}</div>
                  <div className="text-[11px] text-slate-600">
                    {mode.description}
                  </div>
                </span>
              </label>
            ))}
          </div>
          <label className="flex items-center gap-2 text-xs">
            <input
              type="checkbox"
              checked={value.div28.flagAsOptional}
              onChange={(event) => updateDiv28("flagAsOptional", event.target.checked)}
            />
            <span>Mark Div 28 as optional upgrade</span>
          </label>
          <label className="flex items-center gap-2 text-xs">
            <input
              type="checkbox"
              checked={value.div28.showDiv28Disclaimer}
              onChange={(event) =>
                updateDiv28("showDiv28Disclaimer", event.target.checked)
              }
            />
            <span>Show Div 28 disclaimer/coordination note</span>
          </label>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-1">
          <h3 className="font-semibold text-[13px]">Alternative Option</h3>
          <label className="flex items-center gap-2 text-xs">
            <input
              type="checkbox"
              checked={value.includeAlternateOption}
              onChange={(event) =>
                update("includeAlternateOption", event.target.checked)
              }
            />
            <span>Include alternate/value-engineered option</span>
          </label>
          <p className="text-[11px] text-slate-500">
            When enabled, the export builder can generate an alternate
            summary (e.g. lower-cost package or different Div 28 scope).
          </p>
        </div>

        <div className="space-y-1">
          <h3 className="font-semibold text-[13px]">Confidential Terms</h3>
          <label className="flex items-center gap-2 text-xs">
            <input
              type="checkbox"
              checked={value.includeConfidentialTerms}
              onChange={(event) =>
                update("includeConfidentialTerms", event.target.checked)
              }
            />
            <span>Include security/keying confidentiality language</span>
          </label>
          <p className="text-[11px] text-slate-500">
            Recommended when proposals include master-keying, access control,
            or sensitive Div 28 details.
          </p>
        </div>
      </div>
    </div>
  );
};
