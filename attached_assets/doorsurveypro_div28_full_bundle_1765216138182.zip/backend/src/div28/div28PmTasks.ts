// backend/src/div28/div28PmTasks.ts
import { Div28Feature, Div28OpportunitySummary } from "./div28Types";

export type Div28TaskRole =
  | "SALES"
  | "ENGINEERING"
  | "SECURITY_INTEGRATOR"
  | "PROJECT_MANAGER";

export interface Div28TaskTemplate {
  id: string;
  feature: Div28Feature;
  title: string;
  description: string;
  defaultAssigneeRole: Div28TaskRole;
  suggestedDueOffsetDays: number;
}

export interface GeneratedDiv28Task {
  id: string;
  projectId: string;
  openingId: string;
  feature: Div28Feature;
  title: string;
  description: string;
  assigneeRole: Div28TaskRole;
  suggestedDueOffsetDays: number;
}

export const div28TaskTemplates: Div28TaskTemplate[] = [
  {
    id: "ac-001",
    feature: "ACCESS_CONTROL",
    title: "Coordinate access control hardware and credentialing",
    description:
      "Confirm reader locations, controller counts, credential type, and any integration requirements with the customer's access control platform.",
    defaultAssigneeRole: "SECURITY_INTEGRATOR",
    suggestedDueOffsetDays: 3,
  },
  {
    id: "ac-002",
    feature: "ACCESS_CONTROL",
    title: "Review power and wiring requirements for access-controlled openings",
    description:
      "Verify door power supplies, cable routing, and panel space for all access-controlled doors on this project.",
    defaultAssigneeRole: "ENGINEERING",
    suggestedDueOffsetDays: 3,
  },
  {
    id: "auto-001",
    feature: "DOOR_AUTOMATION",
    title: "Validate automatic operator requirements and safety devices",
    description:
      "Confirm operator type, actuation methods, safety sensors, and any touchless/ADA requirements with the owner and AHJ as needed.",
    defaultAssigneeRole: "ENGINEERING",
    suggestedDueOffsetDays: 5,
  },
  {
    id: "eg-001",
    feature: "CONTROLLED_EGRESS",
    title: "Controlled egress code and AHJ coordination",
    description:
      "Review controlled egress configuration for this opening with applicable codes and coordinate approval with the Authority Having Jurisdiction.",
    defaultAssigneeRole: "ENGINEERING",
    suggestedDueOffsetDays: 7,
  },
  {
    id: "eg-002",
    feature: "DELAYED_EGRESS",
    title: "Delayed egress design and fire alarm integration",
    description:
      "Confirm delayed egress timing, alarm behavior, signage, and fire alarm interactions. Coordinate with the fire alarm contractor.",
    defaultAssigneeRole: "ENGINEERING",
    suggestedDueOffsetDays: 7,
  },
  {
    id: "cam-001",
    feature: "SURVEILLANCE",
    title: "Confirm camera placement and field-of-view at opening",
    description:
      "Work with security stakeholders to confirm camera model, placement, coverage area, and integration with the video management system.",
    defaultAssigneeRole: "SECURITY_INTEGRATOR",
    suggestedDueOffsetDays: 5,
  },
  {
    id: "intr-001",
    feature: "INTRUSION_DETECTION",
    title: "Coordinate intrusion detection devices at opening",
    description:
      "Confirm door contacts, motion/glassbreak devices, alarm zoning, and reporting requirements for this opening.",
    defaultAssigneeRole: "SECURITY_INTEGRATOR",
    suggestedDueOffsetDays: 5,
  },
  {
    id: "ld-001",
    feature: "LOCKDOWN_CONTROL",
    title: "Define lockdown behavior for this opening",
    description:
      "Clarify how this opening behaves during local and building-wide lockdown events, including hardware response and override conditions.",
    defaultAssigneeRole: "ENGINEERING",
    suggestedDueOffsetDays: 5,
  },
  {
    id: "threat-001",
    feature: "GUN_DETECTION_READY",
    title: "Coordinate threat detection readiness for this entry",
    description:
      "Confirm analytics-ready coverage (camera/sensor views, pathways) for future or current threat detection solutions selected by the customer.",
    defaultAssigneeRole: "SECURITY_INTEGRATOR",
    suggestedDueOffsetDays: 10,
  },
];

export function buildDiv28TasksForOpening(
  projectId: string,
  openingId: string,
  opportunity: Div28OpportunitySummary
): GeneratedDiv28Task[] {
  const tasks: GeneratedDiv28Task[] = [];
  const features = Array.from(new Set(opportunity.recommendedFeatures));

  for (const feature of features) {
    const templates = div28TaskTemplates.filter(
      (template) => template.feature === feature
    );
    for (const tmpl of templates) {
      tasks.push({
        id: `${projectId}_${openingId}_${tmpl.id}`,
        projectId,
        openingId,
        feature,
        title: tmpl.title,
        description: tmpl.description,
        assigneeRole: tmpl.defaultAssigneeRole,
        suggestedDueOffsetDays: tmpl.suggestedDueOffsetDays,
      });
    }
  }

  return tasks;
}
