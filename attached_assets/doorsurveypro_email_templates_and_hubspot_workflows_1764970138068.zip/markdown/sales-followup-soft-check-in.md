# sales-followup - soft-check-in

**Subject:** Just Checking In 😊

Hi {{FirstName}},  
I hope you’re doing well.  
Just checking in to see if you had any additional thoughts on your project or the proposal we provided.

Let me know how I can help move things forward.
