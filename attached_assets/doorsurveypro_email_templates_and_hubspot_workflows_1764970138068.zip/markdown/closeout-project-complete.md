# closeout - project-complete

**Subject:** Project Completed — Thank You!

Hi {{FirstName}},  
Your project **{{ProjectName}}** is now complete.  
Thank you for choosing DoorSurvey Pro — it was a pleasure working with you.

If you need additional openings surveyed or hardware reviewed, we’re always here.
