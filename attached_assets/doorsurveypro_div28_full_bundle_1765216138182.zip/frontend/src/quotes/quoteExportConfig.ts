// frontend/src/quotes/quoteExportConfig.ts
export type PricingMode =
  | "LINE_ITEM"
  | "OPENING_PACKAGE"
  | "PROJECT_SUMMARY";

export interface Div28ExportMode {
  mode: "NONE" | "INLINE" | "APPENDIX";
  flagAsOptional: boolean;
  showDiv28Disclaimer: boolean;
}

export interface QuoteExportOptions {
  pricingMode: PricingMode;
  showTaxes: boolean;
  showLaborBreakout: boolean;
  showOpeningBreakdown: boolean;
  div28: Div28ExportMode;
  includeAlternateOption: boolean;
  includeConfidentialTerms: boolean;
}

export const defaultQuoteExportOptions: QuoteExportOptions = {
  pricingMode: "OPENING_PACKAGE",
  showTaxes: true,
  showLaborBreakout: true,
  showOpeningBreakdown: true,
  div28: {
    mode: "INLINE",
    flagAsOptional: true,
    showDiv28Disclaimer: true,
  },
  includeAlternateOption: false,
  includeConfidentialTerms: true,
};
