// frontend/src/features/pm/PmBoard.tsx
import React from "react";

export type PmPhaseColumnId =
  | "PRE_CONTRACT"
  | "CONTRACT_EXECUTED"
  | "SUBMITTALS"
  | "PROCUREMENT"
  | "INSTALLATION"
  | "PUNCH"
  | "CLOSEOUT";

export interface PmTaskCard {
  id: string;
  title: string;
  phase: PmPhaseColumnId;
  discipline: string;
  status: string;
  redFlag: boolean;
  assigneeName?: string | null;
  dueDate?: string | null;
}

export interface PmBoardProps {
  tasks: PmTaskCard[];
  onTaskClick?: (task: PmTaskCard) => void;
}

const COLUMNS: { id: PmPhaseColumnId; label: string }[] = [
  { id: "PRE_CONTRACT", label: "Pre-Contract" },
  { id: "CONTRACT_EXECUTED", label: "Contract" },
  { id: "SUBMITTALS", label: "Submittals" },
  { id: "PROCUREMENT", label: "Procurement" },
  { id: "INSTALLATION", label: "Installation" },
  { id: "PUNCH", label: "Punch" },
  { id: "CLOSEOUT", label: "Closeout" },
];

export const PmBoard: React.FC<PmBoardProps> = ({ tasks, onTaskClick }) => {
  const byColumn: Record<PmPhaseColumnId, PmTaskCard[]> = {
    PRE_CONTRACT: [],
    CONTRACT_EXECUTED: [],
    SUBMITTALS: [],
    PROCUREMENT: [],
    INSTALLATION: [],
    PUNCH: [],
    CLOSEOUT: [],
  };

  for (const t of tasks) {
    if (!byColumn[t.phase]) continue;
    byColumn[t.phase].push(t);
  }

  return (
    <div className="grid gap-2 lg:grid-cols-7 md:grid-cols-4 sm:grid-cols-2 text-xs">
      {COLUMNS.map((col) => (
        <div
          key={col.id}
          className="border rounded-md bg-slate-50 flex flex-col max-h-[420px]"
        >
          <div className="px-2 py-1 border-b bg-slate-100 flex items-center justify-between">
            <span className="font-semibold text-[11px]">{col.label}</span>
            <span className="text-[10px] text-slate-500">
              {byColumn[col.id].length}
            </span>
          </div>
          <div className="p-1 space-y-1 overflow-auto">
            {byColumn[col.id].map((task) => (
              <button
                key={task.id}
                type="button"
                onClick={() => onTaskClick?.(task)}
                className={[
                  "w-full text-left rounded-md border px-2 py-1 bg-white hover:bg-slate-100",
                  task.redFlag ? "border-rose-400" : "border-slate-200",
                ].join(" ")}
              >
                <div className="flex justify-between gap-1">
                  <span className="font-semibold text-[11px]">
                    {task.title}
                  </span>
                  {task.redFlag && (
                    <span className="text-[10px] uppercase text-rose-600">
                      Red flag
                    </span>
                  )}
                </div>
                <div className="flex justify-between mt-1 text-[10px] text-slate-600">
                  <span>{task.discipline}</span>
                  <span>{task.status}</span>
                </div>
                {task.assigneeName && (
                  <div className="text-[10px] text-slate-500 mt-0.5">
                    {task.assigneeName}
                  </div>
                )}
                {task.dueDate && (
                  <div className="text-[10px] text-slate-500">
                    Due: {task.dueDate}
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};
