import type {
  MasterKeySystem,
  MasterKeyNode,
  ExportOptions,
} from "./masterKeying";

export interface KeyTreeNode extends MasterKeyNode {
  children: KeyTreeNode[];
}

export function buildKeyTree(system: MasterKeySystem): KeyTreeNode[] {
  const map = new Map<string, KeyTreeNode>();
  system.nodes.forEach((n) =>
    map.set(n.id, { ...n, children: [] as KeyTreeNode[] })
  );
  const roots: KeyTreeNode[] = [];
  map.forEach((node) => {
    if (node.parentId) {
      const parent = map.get(node.parentId);
      if (parent) parent.children.push(node);
      else roots.push(node);
    } else {
      roots.push(node);
    }
  });
  return roots;
}

export function createExportPayload(
  system: MasterKeySystem,
  options: ExportOptions
) {
  const {
    view,
    includeBitting = view === "INTERNAL",
    includeKeyway = view === "INTERNAL",
    includeManufacturer = view === "INTERNAL",
    includeDoorLocationPaths = true,
  } = options;

  const brand = system.brand;

  const nodes = system.nodes.map((node) => ({
    id: node.id,
    code: node.code,
    fullName: node.fullName,
    levelType: node.levelType,
    bitting:
      includeBitting && !brand?.hideBittingOnCustomerView ? node.bitting : null,
    keywayId:
      includeKeyway && !brand?.hideKeywayOnCustomerView ? node.keywayId : null,
    manufacturer:
      includeManufacturer && !brand?.hideManufacturerNamesOnCustomerView
        ? node.manufacturer
        : null,
    parentId: node.parentId,
  }));

  const doors = system.doorOpenings.map((d) => ({
    id: d.id,
    label: d.label,
    locationPath: includeDoorLocationPaths ? d.locationPath : undefined,
  }));

  const assignments = system.assignments.map((a) => ({
    keyNodeId: a.keyNodeId,
    doorId: a.doorId,
  }));

  return {
    system: {
      id: system.id,
      name: system.name,
      facilityName: system.facilityName,
      brand: system.brand,
    },
    nodes,
    doors,
    assignments,
  };
}
