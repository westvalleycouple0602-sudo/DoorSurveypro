# customer-service - issue-update

**Subject:** Update on Your Request

Hi {{FirstName}},  
Here’s an update on your case:

{{StatusUpdate}}

We will notify you as soon as we have the final resolution.
