
#!/usr/bin/env bash
set -euo pipefail

# Choose lean or full requirements (default: lean)
REQ_FILE="${REQ_FILE:-requirements.txt}"

python -m pip install --upgrade pip
python -m pip install -r "$REQ_FILE"

# Run the app on Replit's provided $PORT
python app.py
