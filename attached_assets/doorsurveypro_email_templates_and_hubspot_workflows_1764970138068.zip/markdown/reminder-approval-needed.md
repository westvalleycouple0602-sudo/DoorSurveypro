# reminder - approval-needed

**Subject:** Approval Needed to Move Forward

Hi {{FirstName}},  
We’re ready to proceed with your project, but we need your approval on:

- Proposal  
- Hardware options  
- Schedule  
- Payment terms (if applicable)  

Please reply at your earliest convenience so we can keep your project moving.
