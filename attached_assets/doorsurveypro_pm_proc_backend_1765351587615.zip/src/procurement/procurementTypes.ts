// backend/src/procurement/procurementTypes.ts
export type ManufacturerDomain =
  | "ALLEGION"
  | "ASSA_ABLOY"
  | "DORMAKABA"
  | "STANLEY"
  | "OTHER";

export type ProcurementStatus =
  | "DRAFT"
  | "READY_FOR_REVIEW"
  | "RELEASED_TO_MANUFACTURER"
  | "ON_HOLD"
  | "REVISE_AND_RESUBMIT"
  | "CLOSED";

export interface ProcurementLine {
  id: string;
  openingId?: string | null;
  hardwareSetId?: string | null;
  manufacturer: ManufacturerDomain;
  manufacturerPart: string;
  description: string;
  quantity: number;
  uom: string;
  voltage?: string | null;
  finish?: string | null;
  handing?: string | null;
  fireRating?: string | null;
  notes?: string | null;
  redFlags: string[];
}

export interface ProcurementPackage {
  id: string;
  projectId: string;
  manufacturer: ManufacturerDomain;
  status: ProcurementStatus;
  contactName?: string | null;
  contactEmail?: string | null;
  contactNotes?: string | null;
  createdAt: string;
  updatedAt: string;
  lines: ProcurementLine[];
}
