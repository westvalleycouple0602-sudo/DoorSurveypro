# new-customer - account-created

**Subject:** Your DoorSurvey Pro Account Is Ready

Hi {{FirstName}},  
Your account has been successfully created! You can now:

- Create and manage surveys  
- Upload photos, scans, and LiDAR measurements  
- Track project progress  
- Receive engineering and compliance insights  

Log in here: {{LoginLink}}  

If you have any questions, just reply to this email.
