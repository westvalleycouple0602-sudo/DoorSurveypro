import React, { useMemo } from "react";
import type { MasterKeySystem } from "./masterKeying";
import { createExportPayload } from "./utils";

interface DoorAccessPanelProps {
  system: MasterKeySystem;
  doorId: string;
  view: "INTERNAL" | "CUSTOMER";
  onClose?: () => void;
}

export const DoorAccessPanel: React.FC<DoorAccessPanelProps> = ({
  system,
  doorId,
  view,
  onClose,
}) => {
  const exportData = useMemo(
    () => createExportPayload(system, { view }),
    [system, view]
  );
  const { nodes, doors, assignments } = exportData;
  const nodeById = new Map(nodes.map((n) => [n.id, n]));
  const doorById = new Map(doors.map((d) => [d.id, d]));
  const door = doorById.get(doorId);

  if (!door) {
    return (
      <div className="border rounded-md p-3 text-xs bg-white">
        <div className="flex justify-between items-center mb-2">
          <span className="font-semibold">Door not found</span>
          {onClose && (
            <button
              type="button"
              className="text-xs text-slate-500 hover:text-slate-800"
              onClick={onClose}
            >
              ✕
            </button>
          )}
        </div>
        <p className="text-slate-500">
          This door is not present in the current export payload.
        </p>
      </div>
    );
  }

  const doorAssignments = assignments.filter((a) => a.doorId === doorId);
  const keysForDoor = doorAssignments
    .map((a) => nodeById.get(a.keyNodeId))
    .filter((k): k is NonNullable<typeof k> => !!k);

  const chains: { keyId: string; chain: string }[] =
    view === "INTERNAL"
      ? keysForDoor.map((k) => ({
          keyId: k.id,
          chain: buildKeyChain(nodeById, k.id),
        }))
      : [];

  const chainByKeyId = new Map(chains.map((c) => [c.keyId, c.chain]));

  return (
    <div className="border rounded-md p-3 text-xs bg-white shadow-sm">
      <div className="flex justify-between items-start mb-2">
        <div>
          <div className="text-[11px] text-slate-500 uppercase tracking-wide">
            Door Access
          </div>
          <div className="font-semibold text-sm">{door.label}</div>
          {door.locationPath && (
            <div className="text-[11px] text-slate-500">
              {door.locationPath}
            </div>
          )}
        </div>
        {onClose && (
          <button
            type="button"
            className="text-xs text-slate-500 hover:text-slate-800"
            onClick={onClose}
          >
            ✕
          </button>
        )}
      </div>

      {keysForDoor.length === 0 ? (
        <p className="text-[11px] text-slate-500">
          No keys are assigned to this door in the current system.
        </p>
      ) : (
        <>
          <p className="text-[11px] text-slate-600 mb-1">
            Keys that operate this door:
          </p>
          <div className="max-h-48 overflow-auto border rounded-md">
            <table className="w-full border-collapse text-[11px]">
              <thead>
                <tr className="bg-slate-100">
                  <th className="border px-2 py-1 text-left">Key Code</th>
                  <th className="border px-2 py-1 text-left">Level</th>
                  <th className="border px-2 py-1 text-left">Key Name</th>
                  {view === "INTERNAL" && (
                    <th className="border px-2 py-1 text-left">Hierarchy</th>
                  )}
                </tr>
              </thead>
              <tbody>
                {keysForDoor.map((k, idx) => (
                  <tr
                    key={k.id}
                    className={idx % 2 === 0 ? "bg-white" : "bg-slate-50/60"}
                  >
                    <td className="border px-2 py-1 whitespace-nowrap">
                      {k.code}
                    </td>
                    <td className="border px-2 py-1 whitespace-nowrap">
                      {k.levelType}
                    </td>
                    <td className="border px-2 py-1">
                      {k.fullName ?? k.code}
                    </td>
                    {view === "INTERNAL" && (
                      <td className="border px-2 py-1 text-[10px] text-slate-600">
                        {chainByKeyId.get(k.id) || "–"}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      <div className="mt-2 text-[10px] text-slate-500">
        View:{" "}
        {view === "INTERNAL"
          ? "Internal – full hierarchy shown."
          : "Customer – redacted; shows only key codes/names."}
      </div>
    </div>
  );
};

function buildKeyChain(nodeById: Map<string, any>, keyId: string): string {
  const chain: string[] = [];
  let current = nodeById.get(keyId);
  while (current) {
    chain.push(current.code);
    if (!current.parentId) break;
    current = nodeById.get(current.parentId);
  }
  return chain.reverse().join(" → ");
}
