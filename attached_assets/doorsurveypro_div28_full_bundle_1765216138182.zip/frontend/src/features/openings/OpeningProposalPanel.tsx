// frontend/src/features/openings/OpeningProposalPanel.tsx
import React from "react";
import type { ApiProposalPayload } from "../../api/openingsClientProposals";

export interface OpeningProposalPanelProps {
  openingLabel: string;
  proposal: ApiProposalPayload | null;
}

export const OpeningProposalPanel: React.FC<OpeningProposalPanelProps> = ({
  openingLabel,
  proposal,
}) => {
  if (!proposal) {
    return (
      <div className="border rounded-md p-3 text-xs text-slate-500 bg-slate-50">
        No proposal text has been generated yet for this opening.
      </div>
    );
  }

  return (
    <div className="border rounded-md p-3 bg-white text-xs space-y-3">
      <header className="border-b pb-2 mb-2">
        <h2 className="text-sm font-semibold">
          Proposal Text – {openingLabel}
        </h2>
        <p className="text-[11px] text-slate-500">
          This text can be merged into your quote, export, or PDF layout.
        </p>
      </header>

      <section className="space-y-1">
        <h3 className="text-[12px] font-semibold">Summary</h3>
        <p className="text-[11px] whitespace-pre-wrap">
          {proposal.summary}
        </p>
      </section>

      <section className="space-y-1">
        <h3 className="text-[12px] font-semibold">Base Option</h3>
        <p className="text-[11px] whitespace-pre-wrap">
          {proposal.baseOptionText}
        </p>
      </section>

      {proposal.upgradeBlocks.length > 0 && (
        <section className="space-y-2">
          <h3 className="text-[12px] font-semibold">
            Recommended Electronic &amp; Security Upgrades
          </h3>
          <div className="flex flex-col gap-2">
            {proposal.upgradeBlocks.map((block) => (
              <article
                key={block.id}
                className="border rounded-md p-2 bg-slate-50"
              >
                <h4 className="text-[11px] font-semibold mb-1">
                  {block.title}
                </h4>
                <p className="text-[11px] whitespace-pre-wrap">
                  {block.body}
                </p>
              </article>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
