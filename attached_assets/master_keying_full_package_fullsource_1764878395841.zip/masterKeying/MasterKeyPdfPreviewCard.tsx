import React from "react";
import type { MasterKeySystem, BrandConfig } from "./masterKeying";

interface Props {
  system: MasterKeySystem;
  view: "INTERNAL" | "CUSTOMER";
}

export const MasterKeyPdfPreviewCard: React.FC<Props> = ({ system, view }) => {
  const brand: BrandConfig = system.brand ?? {
    orgName: "DoorSurvey Pro",
    primaryColor: "#F97316",
    secondaryColor: "#0F172A",
    footerText: "© 2025 DoorSurvey Pro – CONFIDENTIAL",
    termsAndConditions:
      "This master key system diagram is confidential. Distribution is strictly limited.",
    watermarkText: "CONFIDENTIAL",
  };

  const primary = brand.primaryColor || "#F97316";
  const secondary = brand.secondaryColor || "#0F172A";

  return (
    <div className="border rounded-md overflow-hidden text-sm max-w-md shadow-sm">
      <div
        className="px-4 py-3 flex items-center justify-between"
        style={{ backgroundColor: secondary, color: "white" }}
      >
        <div className="flex flex-col">
          <span className="text-xs opacity-75">Master Key System</span>
          <span className="font-semibold text-sm">
            {system.name || "Untitled System"}
          </span>
          <span className="text-[10px] opacity-80">
            {system.facilityName || "Facility Name"}
          </span>
        </div>
        <div className="text-right text-[10px] opacity-80">
          <div>{brand.orgName || "Organization"}</div>
          <div>{view === "INTERNAL" ? "Internal View" : "Customer View"}</div>
        </div>
      </div>
      <div className="px-4 py-3 bg-white relative">
        {brand.watermarkText && (
          <div
            className="absolute inset-0 flex items-center justify-center pointer-events-none select-none"
            style={{ opacity: 0.06 }}
          >
            <span
              className="font-bold text-4xl tracking-[0.25em] uppercase"
              style={{ color: secondary }}
            >
              {brand.watermarkText}
            </span>
          </div>
        )}
        <div className="relative z-10 space-y-1">
          <div className="flex items-center justify-between text-[11px]">
            <span className="font-semibold">Key Hierarchy Overview</span>
            <span
              className="px-2 py-[2px] rounded-full text-[10px]"
              style={{ backgroundColor: primary, color: "white" }}
            >
              {view === "INTERNAL" ? "Includes Sensitive Data" : "Redacted"}
            </span>
          </div>
          <p className="text-[11px] text-slate-600">
            PDF export will include a structured outline of GMK → MK → SMK →
            change keys, with assignments summarised per key.
          </p>
          <ul className="text-[10px] text-slate-500 list-disc pl-4">
            <li>
              Bitting:{" "}
              {view === "INTERNAL"
                ? "Shown (unless disabled in brand)"
                : brand.hideBittingOnCustomerView
                ? "Hidden in customer view"
                : "Shown"}
            </li>
            <li>
              Keyway:{" "}
              {view === "INTERNAL"
                ? "Shown (unless disabled)"
                : brand.hideKeywayOnCustomerView
                ? "Hidden in customer view"
                : "Shown"}
            </li>
            <li>
              Manufacturers:{" "}
              {view === "INTERNAL"
                ? "Shown"
                : brand.hideManufacturerNamesOnCustomerView
                ? "Hidden in customer view"
                : "Shown"}
            </li>
          </ul>
        </div>
      </div>
      <div className="px-4 py-2 text-[9px] text-slate-500 bg-slate-50 border-t">
        {brand.footerText ||
          "CONFIDENTIAL – DO NOT DISTRIBUTE WITHOUT WRITTEN AUTHORIZATION."}
      </div>
    </div>
  );
};
