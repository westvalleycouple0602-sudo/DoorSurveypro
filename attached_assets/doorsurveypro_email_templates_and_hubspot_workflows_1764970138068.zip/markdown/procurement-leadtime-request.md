# procurement - leadtime-request

**Subject:** Lead Time Request for {{ProjectName}}

Hello,  
Do you have current lead times for the following hardware items?

Attached: PDF line-item summary.

Thank you!  
{{YourName}}
