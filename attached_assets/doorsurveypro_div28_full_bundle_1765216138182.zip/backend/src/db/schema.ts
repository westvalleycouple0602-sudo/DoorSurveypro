// backend/src/db/schema.ts
import { pgTable, text, timestamp, jsonb } from "drizzle-orm/pg-core";

export const openings = pgTable("openings", {
  id: text("id").primaryKey(),
  projectId: text("project_id").notNull(),
  openingNumber: text("opening_number").notNull(),
  name: text("name"),
  locationDescription: text("location_description"),
  doorFunction: text("door_function").notNull(),
  fireRating: text("fire_rating").notNull(),
  frameMaterial: text("frame_material").notNull(),
  hand: text("hand"),
  roughOpeningWidthMm: text("rough_opening_width_mm"),
  roughOpeningHeightMm: text("rough_opening_height_mm"),
  leafWidthMm: text("leaf_width_mm"),
  leafHeightMm: text("leaf_height_mm"),
  hardwareSetId: text("hardware_set_id"),
  div28Survey: jsonb("div28_survey").notNull(),
  div28Opportunity: jsonb("div28_opportunity"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const div28Tasks = pgTable("div28_tasks", {
  id: text("id").primaryKey(),
  projectId: text("project_id").notNull(),
  openingId: text("opening_id").notNull(),
  feature: text("feature").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  assigneeRole: text("assignee_role").notNull(),
  suggestedDueOffsetDays: text("suggested_due_offset_days"),
});
