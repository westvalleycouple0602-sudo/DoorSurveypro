# Frontend – PM Board & Procurement Checklist (v2)

This frontend bundle provides:

- A PM Kanban-style board component (`PmBoard`) for project phases
- A procurement red-flag checklist panel (`ProcurementChecklistPanel`)

Use it together with the v2 backend which supports Div 28 filtering and tags.
