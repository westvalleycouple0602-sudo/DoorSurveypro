// src/server/db/schema/masterKeySystems.ts
import {
  pgTable,
  varchar,
  text,
  jsonb,
  timestamp,
} from "drizzle-orm/pg-core";

export const masterKeySystems = pgTable("master_key_systems", {
  id: varchar("id", { length: 64 }).primaryKey(), // e.g. "mks_xxx"
  facilityId: varchar("facility_id", { length: 64 }).notNull(),
  name: text("name").notNull(),
  facilityName: text("facility_name").notNull(),
  manufacturer: varchar("manufacturer", { length: 64 }),
  data: jsonb("data").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export type MasterKeySystemRow = typeof masterKeySystems.$inferSelect;
export type NewMasterKeySystemRow = typeof masterKeySystems.$inferInsert;
