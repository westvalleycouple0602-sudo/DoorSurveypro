// src/div28/Div28SurveyForm.tsx
import React from "react";
import {
  Div28SurveyAnswers,
} from "./div28Types";
import {
  div28FormSections,
  Div28FormField,
} from "./div28FormSchema";

export interface Div28SurveyFormProps {
  value: Div28SurveyAnswers;
  onChange: (value: Div28SurveyAnswers) => void;
  disabled?: boolean;
}

function renderField(
  field: Div28FormField,
  value: Div28SurveyAnswers,
  onChange: (id: keyof Div28SurveyAnswers, next: any) => void,
  disabled?: boolean
) {
  const v = value[field.id];

  if (field.type === "boolean") {
    return (
      <label className="flex items-center gap-2 text-xs" key={field.id}>
        <input
          type="checkbox"
          className="h-3 w-3"
          checked={Boolean(v)}
          disabled={disabled}
          onChange={e => onChange(field.id, e.target.checked)}
        />
        <span>
          {field.label}
          {field.helpText && (
            <span className="block text-[10px] text-slate-500">
              {field.helpText}
            </span>
          )}
        </span>
      </label>
    );
  }

  if (field.type === "select") {
    return (
      <div key={field.id} className="space-y-1">
        <label className="text-[11px] font-medium">{field.label}</label>
        <select
          className="border rounded px-2 py-1 text-[11px] w-full bg-white"
          value={String(v ?? "")}
          disabled={disabled}
          onChange={e => onChange(field.id, e.target.value)}
        >
          <option value="">Select…</option>
          {field.options?.map(opt => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
        {field.helpText && (
          <p className="text-[10px] text-slate-500">{field.helpText}</p>
        )}
      </div>
    );
  }

  if (field.type === "textarea") {
    return (
      <div key={field.id} className="space-y-1">
        <label className="text-[11px] font-medium">{field.label}</label>
        <textarea
          className="border rounded px-2 py-1 text-[11px] w-full bg-white min-h-[60px]"
          value={String(v ?? "")}
          disabled={disabled}
          onChange={e => onChange(field.id, e.target.value)}
        />
        {field.helpText && (
          <p className="text-[10px] text-slate-500">{field.helpText}</p>
        )}
      </div>
    );
  }

  return null;
}

export const Div28SurveyForm: React.FC<Div28SurveyFormProps> = ({
  value,
  onChange,
  disabled,
}) => {
  const handleChange = (id: keyof Div28SurveyAnswers, next: any) => {
    onChange({
      ...value,
      [id]: next,
    });
  };

  return (
    <div className="flex flex-col gap-4 text-xs">
      {div28FormSections.map(section => (
        <section
          key={section.id}
          className="border rounded-md bg-white overflow-hidden"
        >
          <header className="px-3 py-2 border-b bg-slate-50">
            <h3 className="font-semibold text-[12px]">{section.title}</h3>
            {section.description && (
              <p className="text-[10px] text-slate-500">
                {section.description}
              </p>
            )}
          </header>
          <div className="p-3 space-y-2">
            {section.fields.map(field =>
              renderField(field, value, handleChange, disabled)
            )}
          </div>
        </section>
      ))}
    </div>
  );
};
