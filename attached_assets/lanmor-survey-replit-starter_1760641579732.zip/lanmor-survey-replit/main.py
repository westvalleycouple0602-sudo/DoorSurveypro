from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse, FileResponse, PlainTextResponse
from jsonschema import Draft202012Validator
import json, os

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
SCHEMA_PATH = os.path.join(APP_ROOT, "data", "schema.json")
TEMPLATE_DIR = os.path.join(APP_ROOT, "templates")

app = FastAPI(title="Lanmor Door Opening Survey API", version="v1")

def load_schema():
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

@app.get("/", response_class=PlainTextResponse)
def root():
    return ("Lanmor Door Opening Survey API\n"
            "Docs: /docs\n"
            "Schema: /schema\n"
            "Templates: /templates\n"
            "Validate: POST /validate")

@app.get("/schema")
def get_schema():
    return JSONResponse(load_schema())

@app.get("/templates")
def list_templates():
    files = [f for f in os.listdir(TEMPLATE_DIR) if f.endswith(".csv")]
    return {"templates": files}

@app.get("/templates/{name}")
def get_template(name: str):
    mapping = {
        "project": "template_project.csv",
        "openings": "template_openings.csv",
        "hardware": "template_hardware.csv",
        "electrification": "template_electrification.csv"
    }
    fname = mapping.get(name.lower())
    if not fname:
        raise HTTPException(404, detail="template not found. use project|openings|hardware|electrification")
    path = os.path.join(TEMPLATE_DIR, fname)
    return FileResponse(path, media_type="text/csv", filename=fname)

@app.post("/validate")
async def validate_payload(payload: dict):
    schema = load_schema()
    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(payload), key=lambda e: e.path)
    if errors:
        return JSONResponse(
            status_code=422,
            content={"ok": False, "errors": [
                {"path": list(e.path), "message": e.message} for e in errors
            ]}
        )
    return {"ok": True, "message": "Payload is valid against schema."}
