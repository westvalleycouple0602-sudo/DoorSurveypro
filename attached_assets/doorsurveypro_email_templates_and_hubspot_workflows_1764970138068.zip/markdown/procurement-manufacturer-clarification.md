# procurement - manufacturer-clarification

**Subject:** Clarification Needed on Order – {{ProjectName}}

Hi {{RepName}},  
We need clarification on the following items from our submitted order:

{{QuestionsList}}

Please advise so we can proceed.
