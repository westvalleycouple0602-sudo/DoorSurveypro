# Sample Openings Dataset (20 records)

This dataset covers common door configurations used in AI + compliance testing.
- Mix of commercial/residential
- Various occupancy types (A/B/E/F/R/S)
- Some fire-rated, some electrified, some accessible
- Geometry and hardware fields match the DoorSurvey AI schema

Use to test:
- /bom and /quote endpoints
- AI compliance engine and rule validations
- AR/LiDAR mapping and overlay visualization