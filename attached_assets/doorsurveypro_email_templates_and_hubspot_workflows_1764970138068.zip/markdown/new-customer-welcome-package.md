# new-customer - welcome-package

**Subject:** Welcome to DoorSurvey Pro – Here’s What Happens Next

Hi {{FirstName}},  
We’re thrilled to partner with you on your upcoming project.  
Here’s what you can expect:

1. **Survey Scheduling** – Our team will confirm your site visit time.  
2. **Information Gathering** – You’ll receive a checklist of any documents we might need.  
3. **Door Survey + Measurement** – Performed using LiDAR/AR for accuracy.  
4. **Engineering Review** – Code compliance, hardware verification, and feasibility checks.  
5. **Proposal Delivery** – A clear, itemized quote with alternatives if needed.  

Let’s build something great!
