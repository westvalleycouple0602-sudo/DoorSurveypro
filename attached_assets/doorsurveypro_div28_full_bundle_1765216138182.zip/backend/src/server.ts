// backend/src/server.ts
import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import openingsRouter from "./openings/openingsRouter";

const app = express();

app.use(cors());
app.use(bodyParser.json());

app.use("/api", openingsRouter);

app.get("/health", (_req, res) => {
  res.json({ ok: true });
});

const port = process.env.PORT || 3001;

app.listen(port, () => {
  console.log(`DoorSurvey Pro Div 8 + 28 API listening on :${port}`);
});
