// backend/src/procurement/procurementEngine.ts
import { v4 as uuidv4 } from "uuid";
import type {
  ManufacturerDomain,
  ProcurementLine,
  ProcurementPackage,
} from "./procurementTypes";

export interface OpeningStubForProcurement {
  id: string;
  projectId: string;
  hardwareSetId?: string | null;
  fireRating?: string | null;
  handing?: string | null;
}

export interface HardwareLineInput {
  openingId: string;
  hardwareSetId: string;
  manufacturer: ManufacturerDomain;
  manufacturerPart: string;
  description: string;
  quantity: number;
  uom?: string;
  voltage?: string | null;
  finish?: string | null;
  handing?: string | null;
  fireRating?: string | null;
}

export function buildRedFlagsForLine(input: HardwareLineInput): string[] {
  const flags: string[] = [];

  if (!input.manufacturerPart) {
    flags.push("Missing manufacturer catalog number.");
  }
  if (!input.description) {
    flags.push("Missing description.");
  }
  if (!input.quantity || input.quantity <= 0) {
    flags.push("Quantity is zero or not specified.");
  }
  if (!input.uom) {
    flags.push("Unit of measure is not specified.");
  }
  if (
    input.voltage &&
    !/^(12V|24V|120V|230V|240V)( AC| DC)?$/.test(input.voltage)
  ) {
    flags.push(`Voltage value "${input.voltage}" should be verified.`);
  }
  if (!input.finish) {
    flags.push("Finish is not specified (e.g., 626, 630, 689).");
  }
  if (!input.fireRating) {
    flags.push("Fire rating is not linked to this hardware line.");
  }
  if (!input.handing) {
    flags.push("Handing is not specified and may be required.");
  }

  return flags;
}

export function groupLinesIntoPackages(
  lines: HardwareLineInput[]
): ProcurementPackage[] {
  const groups = new Map<ManufacturerDomain, HardwareLineInput[]>();
  for (const line of lines) {
    const list = groups.get(line.manufacturer) ?? [];
    list.push(line);
    groups.set(line.manufacturer, list);
  }

  const packages: ProcurementPackage[] = [];
  const now = new Date().toISOString();

  for (const [manufacturer, manuLines] of groups.entries()) {
    const pkgId = uuidv4();
    const lines: ProcurementLine[] = manuLines.map((line) => ({
      id: uuidv4(),
      openingId: line.openingId,
      hardwareSetId: line.hardwareSetId,
      manufacturer,
      manufacturerPart: line.manufacturerPart,
      description: line.description,
      quantity: line.quantity,
      uom: line.uom ?? "EA",
      voltage: line.voltage ?? null,
      finish: line.finish ?? null,
      handing: line.handing ?? null,
      fireRating: line.fireRating ?? null,
      notes: null,
      redFlags: buildRedFlagsForLine(line),
    }));

    const projectId = manuLines[0]?.openingId
      ? manuLines[0].openingId.split(":")[0] ?? "UNKNOWN"
      : "UNKNOWN";

    packages.push({
      id: pkgId,
      projectId,
      manufacturer,
      status: "DRAFT",
      contactName: null,
      contactEmail: null,
      contactNotes: null,
      createdAt: now,
      updatedAt: now,
      lines,
    });
  }

  return packages;
}
