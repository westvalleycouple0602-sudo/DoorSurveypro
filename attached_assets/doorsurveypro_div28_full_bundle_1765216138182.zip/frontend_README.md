# Frontend – Div 28 Proposal, Export Options & Alternate Options

This frontend bundle provides:

- An API client for openings that includes Div 28 tasks + proposal text.
- Helpers to render proposal text as plain text, Markdown, or HTML.
- A React panel to display proposal content on the opening detail screen.
- A Quote Export options form (UI toggles) and alternate option generator.

Drop `frontend/src` into your existing Vite/React + TypeScript app and adjust
import paths if needed.
