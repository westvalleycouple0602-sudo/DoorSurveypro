# DoorSurvey Pro – PM + Procurement Expansion (Monolith-Friendly)

This package contains:

- Backend: Express API for PM tasks & procurement packet building
- Frontend: React components for PM board & procurement red-flag review

## Structure

- backend/src/pm/* – PM task types, templates, and router
- backend/src/procurement/* – Procurement types, engine, and router
- backend/src/server.ts – Express server wiring
- frontend/src/features/pm/PmBoard.tsx – Kanban-style PM board
- frontend/src/features/procurement/ProcurementChecklistPanel.tsx – Red-flag view

Integrate this alongside your existing DoorSurvey Pro monolith backend and React frontend.
